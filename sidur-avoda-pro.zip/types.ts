
export type JobType = 'OPERATIONS' | 'PROJECTS';

// Color themes for dynamic statuses
export type ColorTheme = 'red' | 'blue' | 'green' | 'amber' | 'purple' | 'gray' | 'indigo' | 'pink' | 'cyan';

export type StatusType = 'ACTIVE' | 'INACTIVE' | 'NEUTRAL';

export interface StatusDefinition {
  id: string;
  name: string;
  color: ColorTheme;
  isDefault?: boolean; // System defaults that shouldn't be deleted easily
  type?: StatusType;
  allowedScenes?: string[]; // e.g., 'WORK', 'PRESENCE', 'DISABLING'
}

export type AvailabilityStatus = 'ACTIVE' | 'SICK' | 'VACATION' | 'INACTIVE';

export interface User {
  id: string;
  name: string;
  role: 'ADMIN' | 'MANAGER' | 'TEAM_LEAD' | 'USER';
  active: boolean; // Kept for backward compatibility, syncs with availabilityStatus
  availabilityStatus?: AvailabilityStatus;
  phone?: string;
  email?: string;
  notes?: string;
}

export interface TeamLead {
  id: string;
  name: string;
  active: boolean;
  availabilityStatus?: AvailabilityStatus;
  phone?: string;
  email?: string;
  notes?: string;
  linkedUserId?: string;
}

export interface AssistantTeam {
  id: string;
  leadId?: string;
  name: string;
  active: boolean;
  availabilityStatus?: AvailabilityStatus;
  phone?: string;
  notes?: string;
}

export interface JobEntry {
  id: string;
  date: string; // YYYY-MM-DD
  type: JobType;
  
  // Core Fields
  teamLead: string; 
  teamMembers: string[]; 
  customerName: string; 
  location: string; 
  projectNumber: string; 
  description: string; 
  machsanEquipment?: string; 
  status: string; // Changed from literal union to string to support dynamic statuses
  
  // Additional props
  notes: string;
  platformTypes: ('BAMA' | 'EMDA')[];
  faultType?: string;
  branchName?: string;
  branchNumber?: string;
  contactName?: string;
  contactPhone?: string;
  startTime: string;
  endTime: string;
  startDate?: string; // New: for multi-day projects
  endDate?: string;   // New: for multi-day projects
  dateCreated: string;
}

export interface FirebaseConfig {
  apiKey: string;
  projectId: string;
  authDomain?: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
}

export interface CustomerBranchMemory {
  branchName: string;
  branchNumber: string;
  location: string;
  contactName: string;
  contactPhone: string;
}

export interface CustomerMemory {
  [customerName: string]: {
    branches: { [branchName: string]: CustomerBranchMemory };
    lastUsedBranch?: string;
  };
}

export interface Backup {
  backup_id: string;
  timestamp: string;
  description: string;
  full_state: AppState;
}

export interface AppState {
  users: User[];
  teamLeads: TeamLead[];
  assistantTeams: AssistantTeam[];
  tasks: JobEntry[];
  jobStatuses: StatusDefinition[]; // New dynamic statuses
  faultTypes: string[];
  backups: Backup[];
  firebaseConfig?: FirebaseConfig;
  isCloudEnabled?: boolean;
  customerMemory?: CustomerMemory;
}

// Initial Data

export const INITIAL_STATUSES: StatusDefinition[] = [
  { id: '1', name: 'טיוטה', color: 'gray', isDefault: true, type: 'NEUTRAL', allowedScenes: ['WORK'] },
  { id: '2', name: 'מוקצה', color: 'blue', isDefault: true, type: 'ACTIVE', allowedScenes: ['WORK'] },
  { id: '3', name: 'בביצוע', color: 'amber', isDefault: true, type: 'ACTIVE', allowedScenes: ['WORK'] },
  { id: '4', name: 'הושלם', color: 'green', isDefault: true, type: 'INACTIVE', allowedScenes: ['WORK'] },
  { id: '5', name: 'בדיקה', color: 'purple', isDefault: true, type: 'ACTIVE', allowedScenes: ['WORK'] }
];

export const INITIAL_LEADS: TeamLead[] = [
  { id: '1', name: "שבתי", active: true, availabilityStatus: 'ACTIVE' },
  { id: '2', name: "יוסי", active: true, availabilityStatus: 'ACTIVE' },
  { id: '3', name: "ניר", active: true, availabilityStatus: 'ACTIVE' },
  { id: '4', name: "אלכס בקייב", active: true, availabilityStatus: 'ACTIVE' },
  { id: '5', name: "דוד קב״מ", active: true, availabilityStatus: 'ACTIVE' },
  { id: '6', name: "שחר ענבר", active: true, availabilityStatus: 'ACTIVE' }
];

export const INITIAL_WORKERS: AssistantTeam[] = [
  { id: '1', name: "דורון גבאי", active: true, availabilityStatus: 'ACTIVE' },
  { id: '2', name: "שמואל כהן", active: true, availabilityStatus: 'ACTIVE' },
  { id: '3', name: "אבי לוי", active: true, availabilityStatus: 'ACTIVE' },
  { id: '4', name: "יוסי מזרחי", active: true, availabilityStatus: 'ACTIVE' },
  { id: '5', name: "דני רופ", active: true, availabilityStatus: 'ACTIVE' },
  { id: '6', name: "רונן אדלר", active: true, availabilityStatus: 'ACTIVE' },
  { id: '7', name: "מיכאל גור", active: true, availabilityStatus: 'ACTIVE' },
  { id: '8', name: "עומר אדם", active: true, availabilityStatus: 'ACTIVE' }
];

export const INITIAL_USERS: User[] = [
  { id: '1', name: 'מנהל מערכת', role: 'ADMIN', active: true, availabilityStatus: 'ACTIVE', notes: 'חשבון ראשי' }
];

export const INITIAL_FAULT_TYPES: string[] = [
  'תקלה מכנית',
  'תקלה חשמלית',
  'תקלה בבקר',
  'כיוון ושמן',
  'התקנה חדשה',
  'אחר'
];

export const INITIAL_STATE: AppState = {
  users: INITIAL_USERS,
  teamLeads: INITIAL_LEADS,
  assistantTeams: INITIAL_WORKERS,
  tasks: [],
  jobStatuses: INITIAL_STATUSES,
  faultTypes: INITIAL_FAULT_TYPES,
  backups: [],
  isCloudEnabled: true,
  firebaseConfig: {
    apiKey: "AIzaSyCjoNRzJASMZVeZ33OfArGgzmuDLcSRFDA",
    authDomain: "sidur-avoda-pro.firebaseapp.com",
    projectId: "sidur-avoda-pro",
    storageBucket: "sidur-avoda-pro.firebasestorage.app",
    messagingSenderId: "429952706668",
    appId: "1:429952706668:web:1f403c9437d42bd6229049"
  }
};
