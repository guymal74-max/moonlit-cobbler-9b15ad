
export function formatTime24h(timeString: string): string {
  if (!timeString) return '';
  // Handle both HH:mm and HH:mm:ss formats
  const [hours, minutes] = timeString.split(':');
  return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
}
