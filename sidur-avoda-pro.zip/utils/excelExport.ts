
import ExcelJS from 'exceljs';
import saveAs from 'file-saver';
import { JobEntry } from '../types';
import { format, getMonth, getYear } from 'date-fns';
import { he } from 'date-fns/locale';

export const exportToExcel = async (currentViewDate: string, allJobs: JobEntry[]) => {
  const workbook = new ExcelJS.Workbook();
  const targetYear = getYear(new Date(currentViewDate));
  
  // Hebrew Month Names
  const hebrewMonths = [
    'ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני', 
    'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר'
  ];

  // Styles - Updated for better readability
  const headerFont = { name: 'Arial', bold: true, size: 22, color: { argb: 'FFFFFFFF' } };
  const cellFont = { name: 'Arial', size: 22 };
  const borderStyle: Partial<ExcelJS.Borders> = {
    top: { style: 'thin', color: { argb: 'FF000000' } },
    left: { style: 'thin', color: { argb: 'FF000000' } },
    bottom: { style: 'thin', color: { argb: 'FF000000' } },
    right: { style: 'thin', color: { argb: 'FF000000' } }
  };
  
  const headerFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF8B0000' } } as ExcelJS.Fill;
  const oddFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFFFF' } } as ExcelJS.Fill;
  const evenFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } } as ExcelJS.Fill;
  const separatorFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFb91c1c' } } as ExcelJS.Fill;

  // Define Columns Structure
  const columns = [
    { header: 'תאריך', key: 'date', width: 15 },
    { header: 'יום בשבוע', key: 'day', width: 12 },
    { header: 'ראש צוות', key: 'lead', width: 25 },
    { header: 'שם הלקוח', key: 'customer', width: 25 },
    { header: 'סניף', key: 'branch', width: 20 },
    { header: 'כתובת', key: 'address', width: 35 },
    { header: 'איש קשר', key: 'contact', width: 25 },
    { header: 'מספר הזמנה', key: 'order', width: 15 },
    { header: 'תיאור העבודה', key: 'desc', width: 50 },
    { header: 'סוג תקלה', key: 'fault', width: 20 },
    { header: 'ציוד מהמחסן', key: 'equip', width: 30 },
    { header: 'סטטוס ביצוע', key: 'status', width: 15 },
    { header: 'הערות', key: 'notes', width: 25 },
  ];

  // Loop through 12 months to create sheets
  for (let monthIndex = 0; monthIndex < 12; monthIndex++) {
    const sheetName = `${hebrewMonths[monthIndex]} ${targetYear}`;
    const worksheet = workbook.addWorksheet(sheetName, {
      views: [{ rightToLeft: true, state: 'frozen', ySplit: 2 }],
      pageSetup: { orientation: 'landscape', paperSize: 9 }
    });

    // Add Title Row
    const titleRow = worksheet.getRow(1);
    titleRow.height = 40;
    worksheet.mergeCells(1, 1, 1, columns.length);
    const titleCell = titleRow.getCell(1);
    titleCell.value = 'סידור עבודה - רפי שפירא ובנו';
    titleCell.font = { name: 'Arial', bold: true, size: 22, color: { argb: 'FF8B0000' } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };

    // Add Export Date in top right (which is top left in RTL)
    const exportDateCell = titleRow.getCell(columns.length);
    exportDateCell.value = `תאריך הפקה: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`;
    exportDateCell.font = { name: 'Arial', size: 10, italic: true };
    exportDateCell.alignment = { horizontal: 'left', vertical: 'top' };

    // Add Header Row
    const headerRow = worksheet.getRow(2);
    headerRow.values = columns.map(c => c.header);
    headerRow.height = 30;
    
    headerRow.eachCell((cell) => {
      cell.fill = headerFill;
      cell.font = headerFont;
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = borderStyle;
    });

    // Set Column Widths
    worksheet.columns = columns.map(col => ({ key: col.key, width: col.width }));

    // Add AutoFilter to all columns
    worksheet.autoFilter = {
      from: { row: 2, column: 1 },
      to: { row: 2, column: columns.length }
    };

    // Filter Jobs for this Month & Year
    const monthJobs = allJobs.filter(job => {
      const d = new Date(job.date);
      return getMonth(d) === monthIndex && getYear(d) === targetYear;
    });

    // Sort by Date, then Team Lead
    monthJobs.sort((a, b) => {
      const dateDiff = new Date(a.date).getTime() - new Date(b.date).getTime();
      if (dateDiff !== 0) return dateDiff;
      return a.teamLead.localeCompare(b.teamLead);
    });

    let lastDate = '';
    let rowIndex = 0;

    // Add Data Rows
    monthJobs.forEach(job => {
      // 1. Check for Date Change -> Insert Red Separator Row
      if (job.date !== lastDate) {
        if (lastDate !== '') {
           const separatorRow = worksheet.addRow(['']);
           separatorRow.height = 4;
           worksheet.mergeCells(separatorRow.number, 1, separatorRow.number, columns.length);
           separatorRow.getCell(1).fill = separatorFill;
        }
        lastDate = job.date;
      }

      // 2. Add Job Data
      const dateObj = new Date(job.date);
      const platformStr = job.platformTypes?.length ? ` [${job.platformTypes.map(t => t === 'BAMA' ? 'במה' : 'עמדה').join(', ')}]` : '';
      const row = worksheet.addRow({
        date: format(dateObj, 'dd/MM/yyyy'),
        day: format(dateObj, 'EEEE', { locale: he }),
        lead: `${job.teamLead}${job.teamMembers.length ? '\n(+ ' + job.teamMembers.join(', ') + ')' : ''}`,
        customer: job.customerName,
        branch: `${job.branchName || ''} ${job.branchNumber ? `(${job.branchNumber})` : ''}`,
        address: job.location,
        contact: `${job.contactName || ''} ${job.contactPhone ? `\n${job.contactPhone}` : ''}`,
        order: job.projectNumber,
        desc: `${job.description}${platformStr}\n${job.startTime}-${job.endTime}`,
        fault: job.faultType || '',
        equip: job.machsanEquipment,
        status: job.status,
        notes: job.notes
      });

      // 3. Styling the Row
      row.height = 35;
      rowIndex++;
      
      row.eachCell((cell) => {
        cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
        cell.border = borderStyle;
        cell.font = cellFont;
        cell.fill = rowIndex % 2 === 0 ? evenFill : oddFill;
      });
      
      // Highlight Equipment Cell if not empty
      if (job.machsanEquipment) {
        const equipCell = row.getCell(11);
        equipCell.font = { color: { argb: 'FFb91c1c' }, bold: true, name: 'Arial', size: 22 };
      }
    });
  }

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), `יומן_עבודה_${targetYear}.xlsx`);
};