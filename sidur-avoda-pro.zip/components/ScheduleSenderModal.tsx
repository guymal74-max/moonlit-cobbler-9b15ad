
import React, { useState } from 'react';
import { X, MessageCircle, Printer, User, Calendar as CalendarIcon } from 'lucide-react';
import { JobEntry, TeamLead } from '../types';
import { format } from 'date-fns';
import { he } from 'date-fns/locale';
import { Button } from './ui/Button';

interface ScheduleSenderModalProps {
  jobs: JobEntry[];
  availableLeads: TeamLead[];
  onClose: () => void;
}

export const ScheduleSenderModal: React.FC<ScheduleSenderModalProps> = ({ jobs, availableLeads, onClose }) => {
  const [selectedLead, setSelectedLead] = useState('');
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  
  const filteredJobs = jobs.filter(job => 
    job.teamLead === selectedLead && job.date === selectedDate
  );

  const handleSendWhatsApp = () => {
    if (filteredJobs.length === 0) return;
    
    // Get the selected lead's phone number from state
    const lead = availableLeads.find(l => l.name === selectedLead);
    const rawPhone = lead?.phone || '';
    const managerNumber = rawPhone ? '972' + rawPhone.replace(/^0/, '').replace(/[-\s]/g, '') : '972501234567';
    
    let message = `*סידור עבודה ליום ${format(new Date(selectedDate), 'EEEE dd/MM', { locale: he })}*\n`;
    message += `עבור: *${selectedLead}*\n\n`;
    
    filteredJobs.forEach((job, index) => {
      message += `--- משימה ${index + 1} ---\n`;
      message += `📌 *לקוח: ${job.customerName}*\n`;
      if (job.projectNumber) message += `🔢 מספר: #${job.projectNumber}\n`;
      message += `📍 כתובת: ${job.location}\n`;
      message += `🔗 ניווט: https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(job.location)}\n`;
      message += `📝 תיאור: ${job.description}\n`;
      if (job.machsanEquipment) message += `📦 ציוד: ${job.machsanEquipment}\n`;
      if (job.contactName || job.contactPhone) {
        message += `👤 איש קשר: ${job.contactName || ''} ${job.contactPhone || ''}\n`;
      }
      if (job.platformTypes && job.platformTypes.length > 0) {
        message += `🏗️ סוג: ${job.platformTypes.map(t => t === 'BAMA' ? 'במה' : 'עמדה').join(', ')}\n`;
      }
      message += `⏰ שעות: ${job.startTime}-${job.endTime}\n\n`;
    });
    
    const url = `https://wa.me/${managerNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 no-print">
        <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-gray-200">
          <div className="flex items-center justify-between p-4 md:p-6 border-b bg-green-600 text-white">
            <div className="flex items-center gap-3">
              <MessageCircle className="w-6 h-6" />
              <h2 className="text-xl font-black">שלח סידור עבודה</h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-black text-gray-700 mb-1">בחר איש צוות</label>
                <div className="relative">
                  <User className="absolute right-3 top-3 text-gray-400 w-5 h-5" />
                  <select 
                    className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-green-600 outline-none text-base shadow-sm"
                    value={selectedLead}
                    onChange={(e) => setSelectedLead(e.target.value)}
                  >
                    <option value="">בחר...</option>
                    {availableLeads.map(lead => <option key={lead.id} value={lead.name}>{lead.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-black text-gray-700 mb-1">בחר תאריך</label>
                <div className="relative">
                  <CalendarIcon className="absolute right-3 top-3 text-gray-400 w-5 h-5" />
                  <input 
                    type="date"
                    className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-green-600 outline-none text-base shadow-sm"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-black text-gray-900 border-b pb-2">משימות שנמצאו ({filteredJobs.length})</h3>
              {filteredJobs.length === 0 ? (
                <div className="text-center py-8 text-gray-400 italic">לא נמצאו משימות לחיפוש זה</div>
              ) : (
                <div className="space-y-3">
                  {filteredJobs.map(job => (
                    <div key={job.id} className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-black text-green-700">#{job.projectNumber}</span>
                        <span className="text-xs font-bold bg-white px-2 py-1 rounded border">{job.startTime}-{job.endTime}</span>
                      </div>
                      <div className="font-bold text-gray-900">{job.customerName}</div>
                      <div className="text-sm text-gray-600 truncate">{job.location}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="p-4 border-t bg-gray-50 flex justify-end gap-3">
            <Button variant="ghost" onClick={onClose}>ביטול</Button>
            <Button 
              variant="outline" 
              onClick={handlePrint}
              disabled={filteredJobs.length === 0}
              className="gap-2"
            >
              <Printer size={18} />
              הדפס
            </Button>
            <Button 
              onClick={handleSendWhatsApp}
              disabled={filteredJobs.length === 0}
              className="bg-green-600 hover:bg-green-700 text-white gap-2 px-8"
            >
              <MessageCircle size={18} />
              שלח ב-WhatsApp
            </Button>
          </div>
        </div>
      </div>

      {/* Print Only Section */}
      <div className="print-container hidden print:block">
         <div className="mb-6 text-center border-b-2 border-black pb-4">
            <h1 className="text-3xl font-black">סידור עבודה - רפי שפירא</h1>
            <div className="text-xl font-bold mt-2">
               יום {format(new Date(selectedDate), 'EEEE dd/MM/yyyy', { locale: he })} | עבור: {selectedLead}
            </div>
         </div>
         
         <div className="print-grid">
            {filteredJobs.map(job => (
               <div key={job.id} className="print-card flex flex-col gap-2">
                  <div className="flex justify-between items-center border-b pb-1">
                     <span className="text-xl font-black">#{job.projectNumber}</span>
                     <span className="font-bold">{job.startTime} - {job.endTime}</span>
                  </div>
                  <div className="text-2xl font-black">{job.customerName}</div>
                  <div className="font-bold text-lg">{job.location}</div>
                  <div className="border-t pt-1 mt-1">
                     <div className="font-bold">תיאור: {job.description}</div>
                     {job.machsanEquipment && <div className="font-bold text-red-700">ציוד: {job.machsanEquipment}</div>}
                     {job.contactName && <div className="text-sm">איש קשר: {job.contactName} {job.contactPhone}</div>}
                  </div>
               </div>
            ))}
         </div>
      </div>
    </>
  );
};
