
import React, { useState, useEffect } from 'react';
import { JobEntry, TeamLead, AssistantTeam, StatusDefinition, CustomerMemory } from '../types';
import { X, MapPin, FileText, Box, CheckCircle2, User, Activity, Phone, Plus, Trash2, Edit2, MessageCircle, Calendar } from 'lucide-react';
import { Button } from './ui/Button';

interface JobFormProps {
  initialData?: JobEntry;
  selectedDate: string;
  onSave: (job: JobEntry) => void;
  onCancel: () => void;
  availableLeads: TeamLead[];
  availableWorkers: AssistantTeam[];
  statuses?: StatusDefinition[];
  faultTypes?: string[];
  onUpdateFaultTypes?: (types: string[]) => void;
  customerMemory?: CustomerMemory;
}

export const JobForm: React.FC<JobFormProps> = ({ 
  initialData, 
  selectedDate, 
  onSave, 
  onCancel,
  availableLeads,
  availableWorkers,
  statuses = [],
  faultTypes = [],
  onUpdateFaultTypes,
  customerMemory = {}
}) => {
  const [formData, setFormData] = useState<JobEntry>({
    id: crypto.randomUUID(),
    date: selectedDate,
    type: 'OPERATIONS',
    teamLead: '',
    teamMembers: [],
    customerName: '',
    branchName: '',
    branchNumber: '',
    location: '',
    description: '',
    projectNumber: '',
    notes: '',
    machsanEquipment: '',
    platformTypes: [],
    faultType: '',
    contactName: '',
    contactPhone: '',
    startTime: '07:00',
    endTime: '16:00',
    startDate: selectedDate,
    endDate: selectedDate,
    status: statuses[0]?.name || 'מוקצה',
    dateCreated: new Date().toISOString()
  });

  const [isEditingFaultTypes, setIsEditingFaultTypes] = useState(false);
  const [newFaultType, setNewFaultType] = useState('');
  const [customerSuggestions, setCustomerSuggestions] = useState<string[]>([]);
  const [branchSuggestions, setBranchSuggestions] = useState<string[]>([]);
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false);
  const [showBranchSuggestions, setShowBranchSuggestions] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  const handleChange = (field: keyof JobEntry, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleMember = (member: string) => {
    setFormData(prev => {
      const current = prev.teamMembers;
      if (current.includes(member)) {
        return { ...prev, teamMembers: current.filter(m => m !== member) };
      } else {
        return { ...prev, teamMembers: [...current, member] };
      }
    });
  };

  const togglePlatformType = (type: 'BAMA' | 'EMDA') => {
    setFormData(prev => {
      const current = prev.platformTypes || [];
      if (current.includes(type)) {
        return { ...prev, platformTypes: current.filter(t => t !== type) };
      } else {
        return { ...prev, platformTypes: [...current, type] };
      }
    });
  };

  const handleAddFaultType = () => {
    if (newFaultType.trim() && onUpdateFaultTypes) {
      onUpdateFaultTypes([...faultTypes, newFaultType.trim()]);
      setNewFaultType('');
    }
  };

  const handleDeleteFaultType = (type: string) => {
    if (onUpdateFaultTypes) {
      onUpdateFaultTypes(faultTypes.filter(t => t !== type));
    }
  };

  // Filter only active and present leads/workers (not sick/vacation)
  const activeLeads = availableLeads.filter(l => 
    (l.active && (!l.availabilityStatus || l.availabilityStatus === 'ACTIVE')) || l.name === formData.teamLead
  );
  const activeWorkers = availableWorkers.filter(w => 
    (w.active && (!w.availabilityStatus || w.availabilityStatus === 'ACTIVE')) || formData.teamMembers.includes(w.name)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-0 md:p-4 no-print">
      <div className="bg-white w-full h-full md:h-auto md:max-h-[90vh] md:max-w-3xl md:rounded-2xl shadow-2xl overflow-hidden flex flex-col md:border border-gray-200">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:p-6 border-b bg-primary text-white shrink-0">
          <div>
            <h2 className="text-xl md:text-2xl font-black">
              {initialData ? 'עריכת משימה' : 'פתיחת קריאה'}
            </h2>
            <p className="text-red-100 text-xs md:text-sm italic">רפי שפירא - סידור עבודה</p>
          </div>
          <button onClick={onCancel} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Scrollable Area */}
        <div className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6 space-y-6">
          
          {/* Section 1: Order & Identification */}
          <div className="bg-white p-4 md:p-5 rounded-xl border border-red-100 shadow-sm space-y-4">
             <div className="flex items-center gap-2 text-primary font-black border-b pb-2 mb-4">
                <FileText className="w-5 h-5" />
                <h3>פרטי ההזמנה והלקוח</h3>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">מספר הזמנה / פרויקט</label>
                   <input
                     type="text"
                     className="w-full border border-gray-300 bg-white rounded-lg p-3 text-lg font-mono focus:border-primary focus:ring-0 outline-none shadow-sm"
                     placeholder="הכנס מס' הזמנה"
                     value={formData.projectNumber}
                     onChange={(e) => handleChange('projectNumber', e.target.value)}
                   />
                </div>
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">שם הלקוח</label>
                   <div className="relative">
                     <User className="absolute right-3 top-3.5 text-gray-400 w-5 h-5" />
                     <input
                       type="text"
                       className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-primary outline-none text-base shadow-sm"
                       placeholder="שם הלקוח..."
                       value={formData.customerName}
                       onChange={(e) => {
                         const val = e.target.value;
                         handleChange('customerName', val);
                         if (val.trim()) {
                           const matches = Object.keys(customerMemory).filter(c => c.toLowerCase().includes(val.toLowerCase()));
                           setCustomerSuggestions(matches);
                           setShowCustomerSuggestions(true);
                         } else {
                           setCustomerSuggestions([]);
                           setShowCustomerSuggestions(false);
                         }
                       }}
                       onFocus={() => {
                         if (formData.customerName.trim()) setShowCustomerSuggestions(true);
                       }}
                   />
                   {showCustomerSuggestions && customerSuggestions.length > 0 && (
                     <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden max-h-48 overflow-y-auto">
                       {customerSuggestions.map((s, i) => (
                         <button
                           key={i}
                           type="button"
                           className="w-full text-right px-4 py-2 hover:bg-gray-50 text-sm border-b border-gray-100 last:border-0"
                           onClick={() => {
                             const customer = customerMemory[s];
                             const lastBranch = customer.lastUsedBranch ? customer.branches[customer.lastUsedBranch] : null;
                             setFormData(prev => ({
                               ...prev,
                               customerName: s,
                               branchName: lastBranch?.branchName || '',
                               branchNumber: lastBranch?.branchNumber || '',
                               location: lastBranch?.location || '',
                               contactName: lastBranch?.contactName || '',
                               contactPhone: lastBranch?.contactPhone || ''
                             }));
                             setShowCustomerSuggestions(false);
                           }}
                         >
                           {s}
                         </button>
                       ))}
                     </div>
                   )}
                   </div>
                </div>
             </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">שם סניף</label>
                   <div className="relative">
                     <input
                       type="text"
                       className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                       placeholder="שם הסניף..."
                       value={formData.branchName || ''}
                       onChange={(e) => {
                         const val = e.target.value;
                         handleChange('branchName', val);
                         const customer = customerMemory[formData.customerName];
                         if (customer && val.trim()) {
                           const matches = Object.keys(customer.branches).filter(b => b.toLowerCase().includes(val.toLowerCase()));
                           setBranchSuggestions(matches);
                           setShowBranchSuggestions(true);
                         } else {
                           setBranchSuggestions([]);
                           setShowBranchSuggestions(false);
                         }
                       }}
                       onFocus={() => {
                         if (formData.branchName?.trim()) setShowBranchSuggestions(true);
                       }}
                     />
                     {showBranchSuggestions && branchSuggestions.length > 0 && (
                       <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden max-h-48 overflow-y-auto">
                         {branchSuggestions.map((s, i) => (
                           <button
                             key={i}
                             type="button"
                             className="w-full text-right px-4 py-2 hover:bg-gray-50 text-sm border-b border-gray-100 last:border-0"
                             onClick={() => {
                               const branch = customerMemory[formData.customerName].branches[s];
                               setFormData(prev => ({
                                 ...prev,
                                 branchName: s,
                                 branchNumber: branch.branchNumber,
                                 location: branch.location,
                                 contactName: branch.contactName,
                                 contactPhone: branch.contactPhone
                               }));
                               setShowBranchSuggestions(false);
                             }}
                           >
                             {s}
                           </button>
                         ))}
                       </div>
                     )}
                   </div>
                </div>
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">מספר סניף</label>
                   <input
                     type="text"
                     className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                     placeholder="מספר הסניף..."
                     value={formData.branchNumber || ''}
                     onChange={(e) => handleChange('branchNumber', e.target.value)}
                   />
                </div>
             </div>

             <div>
                <label className="block text-sm font-black text-gray-700 mb-1">כתובת מדויקת של הסניף</label>
                <div className="relative">
                  <MapPin className="absolute right-3 top-3.5 text-gray-400 w-5 h-5" />
                  <input 
                    type="text" 
                    className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-primary outline-none text-base shadow-sm" 
                    placeholder="הכנס כתובת מלאה..."
                    value={formData.location} 
                    onChange={(e) => handleChange('location', e.target.value)} 
                  />
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">איש קשר באתר (שם)</label>
                   <input
                     type="text"
                     className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                     placeholder="שם איש הקשר..."
                     value={formData.contactName || ''}
                     onChange={(e) => handleChange('contactName', e.target.value)}
                   />
                </div>
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">איש קשר באתר (טלפון)</label>
                   <div className="flex gap-2">
                     <div className="relative flex-1">
                       <Phone className="absolute right-3 top-3.5 text-gray-400 w-5 h-5" />
                       <input
                         type="tel"
                         className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-primary outline-none text-base shadow-sm"
                         placeholder="מספר טלפון..."
                         value={formData.contactPhone || ''}
                         onChange={(e) => handleChange('contactPhone', e.target.value)}
                       />
                     </div>
                     {formData.contactPhone && (
                       <button
                         type="button"
                         onClick={() => {
                           const phoneNumber = formData.contactPhone!.replace(/^0/, '').replace(/[-\s]/g, '');
                           window.open('https://wa.me/972' + phoneNumber, '_blank');
                         }}
                         className="bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 transition-colors shadow-sm flex items-center justify-center"
                         title="שלח הודעת WhatsApp"
                       >
                         <MessageCircle size={20} />
                       </button>
                     )}
                   </div>
                </div>
             </div>
          </div>

          {/* Section 2: Logistics & Team */}
          <div className="bg-white p-4 md:p-5 rounded-xl border border-red-100 shadow-sm space-y-4">
             <div className="flex items-center gap-2 text-primary font-black border-b pb-2 mb-4">
                <Activity className="w-5 h-5" />
                <h3>מיקום ולוגיסטיקה</h3>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-700 mb-1">ראש צוות מבצע</label>
                  <select 
                    className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                    value={formData.teamLead}
                    onChange={(e) => handleChange('teamLead', e.target.value)}
                  >
                    <option value="">בחר ראש צוות...</option>
                    {activeLeads.map(lead => <option key={lead.id} value={lead.name}>{lead.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-700 mb-1">סטטוס ביצוע</label>
                  <select 
                    className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                    value={formData.status}
                    onChange={(e) => handleChange('status', e.target.value)}
                  >
                    {statuses.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                  </select>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">תאריך התחלה</label>
                   <div className="relative">
                     <Calendar className="absolute right-3 top-3.5 text-gray-400 w-5 h-5" />
                     <input
                       type="date"
                       className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-primary outline-none text-base shadow-sm"
                       value={formData.startDate || formData.date}
                       onChange={(e) => handleChange('startDate', e.target.value)}
                     />
                   </div>
                </div>
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">תאריך סיום</label>
                   <div className="relative">
                     <Calendar className="absolute right-3 top-3.5 text-gray-400 w-5 h-5" />
                     <input
                       type="date"
                       className="w-full border border-gray-300 bg-white rounded-lg pr-10 pl-3 py-3 focus:border-primary outline-none text-base shadow-sm"
                       value={formData.endDate || formData.date}
                       onChange={(e) => handleChange('endDate', e.target.value)}
                     />
                   </div>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">שעת התחלה (24h)</label>
                   <div className="flex gap-1" dir="ltr">
                      <select 
                        className="flex-1 border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                        value={formData.startTime.split(':')[0]}
                        onChange={(e) => {
                          const mins = formData.startTime.split(':')[1] || '00';
                          handleChange('startTime', `${e.target.value}:${mins}`);
                        }}
                      >
                        {Array.from({ length: 24 }).map((_, i) => {
                          const h = i.toString().padStart(2, '0');
                          return <option key={h} value={h}>{h}</option>;
                        })}
                      </select>
                      <span className="flex items-center font-bold">:</span>
                      <select 
                        className="flex-1 border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                        value={formData.startTime.split(':')[1]}
                        onChange={(e) => {
                          const hrs = formData.startTime.split(':')[0] || '07';
                          handleChange('startTime', `${hrs}:${e.target.value}`);
                        }}
                      >
                        {['00', '15', '30', '45'].map(m => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                   </div>
                </div>
                <div>
                   <label className="block text-sm font-black text-gray-700 mb-1">שעת סיום (24h)</label>
                   <div className="flex gap-1" dir="ltr">
                      <select 
                        className="flex-1 border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                        value={formData.endTime.split(':')[0]}
                        onChange={(e) => {
                          const mins = formData.endTime.split(':')[1] || '00';
                          handleChange('endTime', `${e.target.value}:${mins}`);
                        }}
                      >
                        {Array.from({ length: 24 }).map((_, i) => {
                          const h = i.toString().padStart(2, '0');
                          return <option key={h} value={h}>{h}</option>;
                        })}
                      </select>
                      <span className="flex items-center font-bold">:</span>
                      <select 
                        className="flex-1 border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                        value={formData.endTime.split(':')[1]}
                        onChange={(e) => {
                          const hrs = formData.endTime.split(':')[0] || '16';
                          handleChange('endTime', `${hrs}:${e.target.value}`);
                        }}
                      >
                        {['00', '15', '30', '45'].map(m => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                   </div>
                </div>
             </div>

             <div>
                <label className="block text-sm font-black text-gray-700 mb-2">סיווג משימה</label>
                <div className="flex gap-3">
                  <button
                    onClick={() => handleChange('type', 'OPERATIONS')}
                    className={`flex-1 py-3 px-2 rounded-lg font-bold border-2 transition-all text-sm md:text-base ${formData.type === 'OPERATIONS' ? 'bg-primary border-red-900 text-white shadow-lg' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                  >
                    תפעול ושירות
                  </button>
                  <button
                    onClick={() => handleChange('type', 'PROJECTS')}
                    className={`flex-1 py-3 px-2 rounded-lg font-bold border-2 transition-all text-sm md:text-base ${formData.type === 'PROJECTS' ? 'bg-amber-600 border-amber-800 text-white shadow-lg' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                  >
                    פרויקטים
                  </button>
                </div>
             </div>

             <div>
                <label className="block text-sm font-black text-gray-700 mb-2">צוות נוסף (עוזרים)</label>
                <div className="flex flex-wrap gap-2">
                  {activeWorkers.length === 0 && <span className="text-gray-400 text-sm">לא הוגדרו צוותים נלווים זמינים.</span>}
                  {activeWorkers.map(worker => (
                    <button
                      key={worker.id}
                      type="button"
                      onClick={() => toggleMember(worker.name)}
                      className={`px-3 py-2 rounded-full text-sm font-bold border transition-all ${
                        formData.teamMembers.includes(worker.name)
                          ? 'bg-primary border-red-800 text-white shadow-md'
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {worker.name}
                    </button>
                  ))}
                </div>
             </div>
          </div>

          {/* Section 3: Work Details & Equipment */}
          <div className="bg-white p-4 md:p-5 rounded-xl border border-red-100 shadow-sm space-y-4">
             <div className="flex items-center gap-2 text-primary font-black border-b pb-2 mb-4">
                <Box className="w-5 h-5" />
                <h3>פרטי העבודה וציוד</h3>
             </div>

             <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-black text-gray-700 mb-1">סוג מתקן (ניתן לבחור שניהם)</label>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => togglePlatformType('BAMA')}
                      className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all ${formData.platformTypes?.includes('BAMA') ? 'bg-white border-primary ring-2 ring-red-100 shadow-sm' : 'bg-white border-gray-200 hover:bg-gray-50'}`}
                    >
                      <CheckCircle2 className={`w-5 h-5 ${formData.platformTypes?.includes('BAMA') ? 'text-primary' : 'text-gray-300'}`} />
                      <span className="text-lg font-black">במה</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => togglePlatformType('EMDA')}
                      className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all ${formData.platformTypes?.includes('EMDA') ? 'bg-white border-primary ring-2 ring-red-100 shadow-sm' : 'bg-white border-gray-200 hover:bg-gray-50'}`}
                    >
                      <CheckCircle2 className={`w-5 h-5 ${formData.platformTypes?.includes('EMDA') ? 'text-primary' : 'text-gray-300'}`} />
                      <span className="text-lg font-black">עמדה</span>
                    </button>
                  </div>
                </div>

                <div>
                   <div className="flex items-center justify-between mb-1">
                      <label className="block text-sm font-black text-gray-700">סוג תקלה</label>
                      <button 
                        type="button"
                        onClick={() => setIsEditingFaultTypes(true)}
                        className="text-xs text-primary hover:underline font-bold flex items-center gap-1"
                      >
                        <Edit2 size={12} />
                        ערוך רשימה
                      </button>
                   </div>
                   <select 
                     className="w-full border border-gray-300 bg-white rounded-lg p-3 focus:border-primary outline-none text-base shadow-sm"
                     value={formData.faultType || ''}
                     onChange={(e) => handleChange('faultType', e.target.value)}
                   >
                     <option value="">בחר סוג תקלה...</option>
                     {faultTypes.map((type, idx) => <option key={idx} value={type}>{type}</option>)}
                   </select>
                </div>

                <div>
                  <label className="block text-sm font-black text-gray-700 mb-1">תיאור העבודה</label>
                  <textarea
                    rows={3}
                    className="w-full border border-gray-300 bg-white rounded-lg p-3 outline-none focus:border-primary text-base shadow-sm"
                    placeholder="תיאור מפורט..."
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-black text-gray-700 mb-1 flex items-center gap-2">
                    <Box className="w-4 h-4" />
                    ציוד מהמחסן (חובה למלא)
                  </label>
                  <textarea
                    rows={3}
                    className="w-full border border-gray-300 bg-white rounded-lg p-3 outline-none focus:border-primary text-base shadow-sm"
                    placeholder="פירוט ציוד..."
                    value={formData.machsanEquipment}
                    onChange={(e) => handleChange('machsanEquipment', e.target.value)}
                  />
                </div>
             </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-100 bg-white md:bg-gray-50 flex justify-between md:justify-end gap-3 shrink-0 pb-6 md:pb-4 safe-area-pb">
          <Button variant="ghost" onClick={onCancel} className="font-bold flex-1 md:flex-none">ביטול</Button>
          <Button onClick={() => onSave(formData)} className="font-black text-lg bg-primary hover:bg-red-800 flex-1 md:flex-none md:px-12">
            {initialData ? 'שמור שינויים' : 'צור קריאה'}
          </Button>
        </div>

        {/* Fault Types Edit Modal */}
        {isEditingFaultTypes && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-gray-200">
              <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
                <h3 className="font-black text-gray-900">ניהול סוגי תקלות</h3>
                <button onClick={() => setIsEditingFaultTypes(false)} className="p-1 hover:bg-gray-200 rounded-full">
                  <X size={20} />
                </button>
              </div>
              <div className="p-4 space-y-4">
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-primary"
                    placeholder="סוג תקלה חדש..."
                    value={newFaultType}
                    onChange={(e) => setNewFaultType(e.target.value)}
                  />
                  <Button onClick={handleAddFaultType} size="sm" className="gap-1">
                    <Plus size={16} />
                    הוסף
                  </Button>
                </div>
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {faultTypes.map((type, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg border border-gray-100">
                      <span className="font-medium">{type}</span>
                      <button 
                        onClick={() => handleDeleteFaultType(type)}
                        className="text-red-500 hover:bg-red-50 p-1 rounded"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-4 border-t bg-gray-50 flex justify-end">
                <Button onClick={() => setIsEditingFaultTypes(false)}>סגור</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
