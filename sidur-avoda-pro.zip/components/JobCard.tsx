
import React from 'react';
import { JobEntry, StatusDefinition, ColorTheme } from '../types';
import { Edit2, Trash2, MapPin, Clock, Users, Box, AlertTriangle, User, Navigation, MessageCircle, Tag } from 'lucide-react';
import { formatTime24h } from '../utils/timeUtils';

interface JobCardProps {
  job: JobEntry;
  statuses?: StatusDefinition[];
  onEdit: (job: JobEntry) => void;
  onDelete: (id: string) => void;
}

const THEME_STYLES: Record<ColorTheme, string> = {
  red: 'bg-red-600 text-white border-red-700',
  blue: 'bg-blue-600 text-white border-blue-700',
  green: 'bg-green-600 text-white border-green-700',
  amber: 'bg-amber-500 text-white border-amber-600',
  purple: 'bg-purple-600 text-white border-purple-700',
  gray: 'bg-gray-600 text-white border-gray-700',
  indigo: 'bg-indigo-600 text-white border-indigo-700',
  pink: 'bg-pink-600 text-white border-pink-700',
  cyan: 'bg-cyan-600 text-white border-cyan-700'
};

export const JobCard: React.FC<JobCardProps> = ({ job, statuses = [], onEdit, onDelete }) => {
  const isOps = job.type === 'OPERATIONS';
  // Border on the right for RTL layout strip
  const borderColor = isOps ? 'border-r-blue-600' : 'border-r-amber-500';

  // Determine status style
  const statusDef = statuses.find(s => s.name === job.status);
  const statusColor = statusDef ? statusDef.color : 'gray';
  const statusClass = THEME_STYLES[statusColor] || THEME_STYLES.gray;
  
  const handleNavigate = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (job.location) {
      const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(job.location)}`;
      window.open(url, '_blank');
    }
  };
  
  return (
    <div className={`group bg-white rounded-xl shadow-sm border border-gray-200 border-r-4 ${borderColor} p-4 hover:shadow-md transition-all relative overflow-hidden`}>
      
      {/* 1. Order Number - TOP CENTER */}
      {job.projectNumber && (
        <div className="flex justify-center mb-2">
          <span className="text-xl font-bold text-gray-800">
            #{job.projectNumber}
          </span>
        </div>
      )}

      {/* 2. Status Badge - BELOW Order Number */}
      <div className="flex justify-center mb-4">
        <span className={`text-sm font-black px-6 py-1.5 rounded-full border shadow-md whitespace-nowrap ${statusClass}`}>
          {job.status}
        </span>
      </div>

      {/* 3. Customer Name - LARGE BOLD */}
      {job.customerName && (
         <div className="flex flex-col items-center mb-4 text-center">
            <div className="flex items-center justify-center mb-1">
              <User className="w-6 h-6 ml-2 text-primary shrink-0" />
              <span className="text-3xl font-black text-gray-900 leading-none">{job.customerName}</span>
            </div>
            {(job.branchName || job.branchNumber) && (
              <div className="flex flex-col items-center gap-1 mt-1">
                {job.branchName && (
                  <span className="text-xl font-black text-primary bg-red-50 px-4 py-1 rounded-lg border border-red-100">
                    סניף: {job.branchName}
                  </span>
                )}
                {job.branchNumber && (
                  <span className="text-sm font-bold text-gray-500">
                    מספר סניף: {job.branchNumber}
                  </span>
                )}
              </div>
            )}
         </div>
      )}

      {/* 4. Contact Person + WhatsApp Button */}
      {(job.contactName || job.contactPhone) && (
        <div className="mb-4 bg-green-50/50 p-3 rounded-xl border border-green-100 flex flex-col items-center gap-2">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-green-600" />
            <span className="font-bold text-green-900 text-lg">{job.contactName || 'איש קשר'}</span>
          </div>
          {job.contactPhone && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                const phoneNumber = job.contactPhone!.replace(/^0/, '').replace(/[-\s]/g, '');
                window.open('https://wa.me/972' + phoneNumber, '_blank');
              }}
              className="flex items-center gap-2 bg-green-600 text-white px-6 py-2 rounded-full text-base font-black hover:bg-green-700 transition-colors shadow-md"
            >
              <MessageCircle size={18} />
              {job.contactPhone}
            </button>
          )}
        </div>
      )}

      {/* 5. Address with Navigation Button */}
      {job.location && (
        <div className="mb-4 bg-blue-50/30 p-3 rounded-xl border border-blue-100 flex items-center justify-between group/loc">
          <div className="flex items-center gap-2 min-w-0">
            <MapPin className="w-5 h-5 text-blue-600 shrink-0" />
            <span className="text-xl font-bold text-blue-900 truncate">{job.location}</span>
          </div>
          <button 
            onClick={handleNavigate}
            className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-md shrink-0 flex items-center justify-center"
            title="נווט ב-Google Maps"
          >
            <Navigation size={18} />
          </button>
        </div>
      )}

      {/* Header: Team Lead Name (Remaining info) */}
      <div className="flex justify-between items-start mb-3 gap-2 border-t pt-3">
         <div className="flex-1">
            <h2 className="text-lg font-bold text-gray-900 leading-tight">
               מבצע: {job.teamLead}
            </h2>
            {job.teamMembers.length > 0 && (
               <div className="text-xs text-gray-500 mt-1 flex items-center gap-1 font-medium">
                  <Users className="w-3 h-3" />
                  עוזרים: {job.teamMembers.join(', ')}
               </div>
            )}
         </div>
      </div>

      {/* Time Bar */}
      <div className="flex items-center gap-3 text-xs text-gray-500 mb-3 bg-gray-50 p-2 rounded-lg border border-gray-100">
         <div className="flex items-center font-bold text-gray-700 whitespace-nowrap">
            <Clock className="w-3.5 h-3.5 ml-1.5 text-primary" />
            {formatTime24h(job.startTime)} - {formatTime24h(job.endTime)}
         </div>
      </div>

      {/* Prominent Work Details Section */}
      <div className="space-y-3 mb-4">
        {/* Description Box */}
        <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 shadow-sm">
           <div className="flex items-center justify-between mb-1">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">תיאור העבודה / תקלה:</div>
              {job.faultType && (
                <div className="flex items-center gap-1 text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-black">
                  <Tag size={10} />
                  {job.faultType}
                </div>
              )}
           </div>
           <h3 className="font-black text-gray-900 text-lg leading-tight">
             {job.description}
           </h3>
        </div>

        {/* Warehouse Equipment - Prominent Red Box */}
        {job.machsanEquipment && (
          <div className="bg-red-50 border-r-4 border-primary rounded-l-xl p-3 shadow-sm ring-1 ring-red-100">
              <div className="flex items-center gap-2 text-primary font-black text-xs mb-1">
                  <Box className="w-4 h-4" />
                  ציוד נדרש מהמחסן:
              </div>
              <p className="text-red-900 font-black text-lg leading-tight">
                  {job.machsanEquipment}
              </p>
          </div>
        )}
      </div>

      {/* Footer Tags */}
      <div className="flex flex-wrap gap-3 items-center mt-4 pt-3 border-t border-gray-100">
          {job.platformTypes && job.platformTypes.length > 0 && (
            <div className="flex gap-2">
              {job.platformTypes.map(type => (
                <span key={type} className={`inline-flex items-center gap-2 text-sm font-black px-4 py-2 rounded-xl border-2 shadow-sm ${
                  type === 'BAMA' ? 'bg-blue-100 text-blue-800 border-blue-300' : 'bg-red-100 text-red-800 border-red-300'
                }`}>
                  {type === 'BAMA' ? '🏗️ במה' : '🛑 עמדה'}
                </span>
              ))}
            </div>
          )}
          {job.notes && (
             <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-1 rounded border border-amber-200 flex items-center gap-1 max-w-full truncate">
               <AlertTriangle className="w-3 h-3 shrink-0" />
               {job.notes}
             </span>
          )}
      </div>

      {/* Actions Buttons */}
      <div className="absolute top-3 left-3 flex gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity z-10">
        <button 
          onClick={(e) => { e.stopPropagation(); onEdit(job); }}
          className="p-1.5 bg-white text-blue-600 hover:bg-blue-50 border border-gray-200 rounded-lg shadow-sm"
          title="ערוך"
        >
          <Edit2 className="w-4 h-4" />
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); onDelete(job.id); }}
          className="p-1.5 bg-white text-red-600 hover:bg-red-50 border border-gray-200 rounded-lg shadow-sm"
          title="מחק"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
