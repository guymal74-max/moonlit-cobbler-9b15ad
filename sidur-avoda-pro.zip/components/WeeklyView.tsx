
import React from 'react';
import { JobEntry } from '../types';
import { format, addDays, isSameDay } from 'date-fns';
import { he } from 'date-fns/locale';
import { formatTime24h } from '../utils/timeUtils';

interface WeeklyViewProps {
  currentDate: string;
  jobs: JobEntry[];
}

export const WeeklyView: React.FC<WeeklyViewProps> = ({ currentDate, jobs }) => {
  const dateObj = new Date(currentDate);
  const start = addDays(dateObj, -dateObj.getDay()); // Sunday start replacement for startOfWeek
  const weekDays = Array.from({ length: 6 }).map((_, i) => addDays(start, i)); // Sun-Fri

  return (
    <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-200">
      <h2 className="text-lg md:text-xl font-bold mb-4 md:mb-6 text-gray-800 flex flex-col md:flex-row md:items-center gap-2">
        <span>תצוגה שבועית - מנהלים</span>
        <span className="text-sm font-normal text-gray-500">
          ({format(weekDays[0], 'dd/MM', { locale: he })} - {format(weekDays[5], 'dd/MM', { locale: he })})
        </span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {weekDays.map((day) => {
          const dayJobs = jobs.filter(job => isSameDay(new Date(job.date), day));
          const isToday = isSameDay(new Date(currentDate), day);

          return (
            <div 
              key={day.toISOString()} 
              className={`flex flex-col rounded-lg border min-h-[150px] md:h-full ${isToday ? 'border-primary ring-1 ring-primary bg-red-50/30' : 'border-gray-200 bg-gray-50'}`}
            >
              <div className={`p-3 text-center border-b ${isToday ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700'} rounded-t-lg`}>
                <div className="font-bold">{format(day, 'EEEE', { locale: he })}</div>
                <div className="text-xs opacity-90">{format(day, 'dd/MM', { locale: he })}</div>
              </div>
              
              <div className="p-2 space-y-2 flex-1 overflow-y-auto md:max-h-[400px]">
                {dayJobs.length === 0 && (
                  <div className="text-center text-gray-400 text-xs py-4">אין עבודות</div>
                )}
                {dayJobs.map(job => (
                  <div key={job.id} className="bg-white p-2 rounded border border-gray-200 shadow-sm text-xs">
                    <div className="flex justify-between items-start mb-1">
                      <div className="font-bold text-primary">{job.teamLead}</div>
                      <div className="text-[10px] bg-gray-100 px-1 rounded">{formatTime24h(job.startTime)}</div>
                    </div>
                    <div className="text-gray-600 truncate mb-0.5">
                      {job.location}
                      {job.branchName && <span className="text-[10px] text-gray-400 mr-1">({job.branchName})</span>}
                    </div>
                    <div className="pt-1 border-t border-gray-100 text-gray-500 line-clamp-2">
                      {job.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};