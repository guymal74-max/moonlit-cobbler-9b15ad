
import React, { useState, useRef } from 'react';
import { User, TeamLead, AssistantTeam, StatusDefinition, ColorTheme, AvailabilityStatus, AppState, FirebaseConfig } from '../types';
import { Plus, Edit2, Trash2, CheckCircle, User as UserIcon, Users, Briefcase, Search, Save, X, Phone, Power, Plane, Thermometer, List, Database, Download, Upload, Cloud, ShieldCheck, ShieldAlert } from 'lucide-react';
import { Button } from './ui/Button';
import saveAs from 'file-saver';
import { format } from 'date-fns';

interface AdminPanelProps {
  users: User[];
  leads: TeamLead[];
  assistants: AssistantTeam[];
  statuses: StatusDefinition[];
  fullState?: AppState;
  onUpdateUsers: (users: User[]) => void;
  onUpdateLeads: (leads: TeamLead[]) => void;
  onUpdateAssistants: (assistants: AssistantTeam[]) => void;
  onUpdateStatuses: (statuses: StatusDefinition[]) => void;
  onRestore?: (state: AppState) => void;
  onDeleteUser: (id: string) => void;
  onDeleteLead: (id: string) => void;
  onDeleteAssistant: (id: string) => void;
  onUpdateFirebaseConfig?: (config: FirebaseConfig) => void;
  onToggleCloud?: (enabled: boolean) => void;
  onClose: () => void;
}

type TabType = 'LEADS' | 'ASSISTANTS' | 'USERS' | 'STATUSES' | 'DATA' | 'CLOUD';

const THEME_OPTIONS: { value: ColorTheme; label: string; bg: string }[] = [
  { value: 'gray', label: 'אפור', bg: 'bg-gray-500' },
  { value: 'red', label: 'אדום', bg: 'bg-red-500' },
  { value: 'blue', label: 'כחול', bg: 'bg-blue-500' },
  { value: 'green', label: 'ירוק', bg: 'bg-green-500' },
  { value: 'amber', label: 'כתום', bg: 'bg-amber-500' },
  { value: 'purple', label: 'סגול', bg: 'bg-purple-500' },
  { value: 'cyan', label: 'טורקיז', bg: 'bg-cyan-500' },
  { value: 'pink', label: 'וורוד', bg: 'bg-pink-500' },
  { value: 'indigo', label: 'אינדיגו', bg: 'bg-indigo-500' },
];

const SCENE_OPTIONS = [
  { id: 'WORK', label: 'ביצוע עבודה' },
  { id: 'PRESENCE', label: 'נוכחות' },
  { id: 'DISABLING', label: 'השבתה' }
];

export const AdminPanel: React.FC<AdminPanelProps> = ({
  users, leads, assistants, statuses, fullState,
  onUpdateUsers, onUpdateLeads, onUpdateAssistants, onUpdateStatuses, onRestore,
  onDeleteUser, onDeleteLead, onDeleteAssistant,
  onUpdateFirebaseConfig, onToggleCloud,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('LEADS');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Cloud State
  const [tempFirebaseConfig, setTempFirebaseConfig] = useState<FirebaseConfig>(fullState?.firebaseConfig || { apiKey: '', projectId: '' });
  
  // Editing State
  const [isEditing, setIsEditing] = useState(false);
  const [editType, setEditType] = useState<TabType | null>(null);
  
  // Status Modal State
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);
  const [selectedPersonType, setSelectedPersonType] = useState<'LEAD' | 'ASSISTANT' | null>(null);

  // Delete Confirmation State
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string, type: TabType, name: string } | null>(null);
  
  // Typed temporary state for forms
  const [tempUser, setTempUser] = useState<Partial<User>>({});
  const [tempLead, setTempLead] = useState<Partial<TeamLead>>({});
  const [tempAssistant, setTempAssistant] = useState<Partial<AssistantTeam>>({});
  const [tempStatus, setTempStatus] = useState<Partial<StatusDefinition>>({});

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Handlers ---

  const handleOpenEdit = (type: TabType, item?: any) => {
    setEditType(type);
    setIsEditing(true);
    
    if (type === 'USERS') {
      setTempUser(item ? { ...item } : { active: true, role: 'USER' });
    } else if (type === 'LEADS') {
      setTempLead(item ? { ...item } : { active: true, availabilityStatus: 'ACTIVE' });
    } else if (type === 'ASSISTANTS') {
      setTempAssistant(item ? { ...item } : { active: true, availabilityStatus: 'ACTIVE' });
    } else if (type === 'STATUSES') {
      setTempStatus(item ? { ...item } : { color: 'gray', type: 'ACTIVE', allowedScenes: ['WORK'] });
    }
  };

  const handleSave = () => {
    if (editType === 'USERS') {
      if (!tempUser.name) return alert('נא להזין שם משתמש');
      const newUser = { ...tempUser, id: tempUser.id || crypto.randomUUID() } as User;
      onUpdateUsers(tempUser.id ? users.map(u => u.id === newUser.id ? newUser : u) : [...users, newUser]);
    } 
    else if (editType === 'LEADS') {
      if (!tempLead.name) return alert('נא להזין שם ראש צוות');
      const newLead = { ...tempLead, id: tempLead.id || crypto.randomUUID() } as TeamLead;
      onUpdateLeads(tempLead.id ? leads.map(l => l.id === newLead.id ? newLead : l) : [...leads, newLead]);
    } 
    else if (editType === 'ASSISTANTS') {
      if (!tempAssistant.name) return alert('נא להזין שם איש צוות');
      const newAssistant = { ...tempAssistant, id: tempAssistant.id || crypto.randomUUID() } as AssistantTeam;
      onUpdateAssistants(tempAssistant.id ? assistants.map(a => a.id === newAssistant.id ? newAssistant : a) : [...assistants, newAssistant]);
    }
    else if (editType === 'STATUSES') {
      if (!tempStatus.name) return alert('נא להזין שם סטטוס');
      const newStatus = { ...tempStatus, id: tempStatus.id || crypto.randomUUID() } as StatusDefinition;
      onUpdateStatuses(tempStatus.id ? statuses.map(s => s.id === newStatus.id ? newStatus : s) : [...statuses, newStatus]);
    }
    setIsEditing(false);
  };

  const handleDeleteClick = (id: string, type: TabType) => {
    let name = '';
    if (type === 'USERS') name = users.find(u => u.id === id)?.name || 'משתמש';
    else if (type === 'LEADS') name = leads.find(l => l.id === id)?.name || 'ראש צוות';
    else if (type === 'ASSISTANTS') name = assistants.find(a => a.id === id)?.name || 'איש צוות';
    else if (type === 'STATUSES') name = statuses.find(s => s.id === id)?.name || 'סטטוס';
    
    setDeleteConfirm({ id, type, name });
  };

  const confirmDelete = () => {
    if (!deleteConfirm) return;
    const { id, type } = deleteConfirm;
    
    if (type === 'USERS') onDeleteUser(id);
    else if (type === 'LEADS') onDeleteLead(id);
    else if (type === 'ASSISTANTS') onDeleteAssistant(id);
    else if (type === 'STATUSES') onUpdateStatuses(statuses.filter(s => s.id !== id));
    
    setDeleteConfirm(null);
  };

  const openStatusModal = (id: string, type: 'LEAD' | 'ASSISTANT') => {
    setSelectedPersonId(id);
    setSelectedPersonType(type);
    setIsStatusModalOpen(true);
  };

  const handleSetAvailability = (status: AvailabilityStatus) => {
    if (!selectedPersonId || !selectedPersonType) return;
    const isActive = status === 'ACTIVE';

    if (selectedPersonType === 'LEAD') {
      onUpdateLeads(leads.map(l => l.id === selectedPersonId ? { ...l, active: isActive, availabilityStatus: status } : l));
    } else {
      onUpdateAssistants(assistants.map(a => a.id === selectedPersonId ? { ...a, active: isActive, availabilityStatus: status } : a));
    }
    setIsStatusModalOpen(false);
  };

  const toggleScene = (sceneId: string) => {
    setTempStatus(prev => {
      const scenes = prev.allowedScenes || [];
      if (scenes.includes(sceneId)) {
        return { ...prev, allowedScenes: scenes.filter(s => s !== sceneId) };
      } else {
        return { ...prev, allowedScenes: [...scenes, sceneId] };
      }
    });
  };

  // --- Backup Handlers ---
  const handleExportBackup = () => {
    if (!fullState) return;
    const blob = new Blob([JSON.stringify(fullState, null, 2)], { type: 'application/json;charset=utf-8' });
    const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm');
    saveAs(blob, `sidur_avoda_backup_${timestamp}.json`);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onRestore) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json && json.tasks) {
          onRestore(json);
        } else {
          alert('קובץ לא תקין או פגום');
        }
      } catch (err) {
        alert('שגיאה בקריאת הקובץ');
      }
    };
    reader.readAsText(file);
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // --- Render Helpers ---

  const StatusBadge = ({ status, onClick }: { status?: AvailabilityStatus; onClick?: () => void }) => {
    let color = 'bg-gray-100 text-gray-600';
    let icon = <Power size={12} />;
    let text = 'לא פעיל';

    if (status === 'ACTIVE') { color = 'bg-green-100 text-green-700'; icon = <CheckCircle size={12} />; text = 'פעיל'; }
    if (status === 'SICK') { color = 'bg-red-100 text-red-700'; icon = <Thermometer size={12} />; text = 'מחלה'; }
    if (status === 'VACATION') { color = 'bg-blue-100 text-blue-700'; icon = <Plane size={12} />; text = 'חופשה'; }

    return (
      <button onClick={onClick} className={`px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1 w-fit transition-transform hover:scale-105 ${color} shadow-sm border border-black/5`}>
        {icon} {text}
      </button>
    );
  };

  const filterItems = (items: any[]) => {
    return items.filter(i => i.name.toLowerCase().includes(searchTerm.toLowerCase()));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 no-print">
      <div className="bg-white w-full max-w-5xl h-[85vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-primary text-white p-4 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-white/10 rounded-lg"><Briefcase size={24} /></div>
             <div>
               <h2 className="text-xl font-black">ניהול מערכת</h2>
               <p className="text-red-100 text-xs">ניהול משתמשים, צוותים, סטטוסים וגיבויים</p>
             </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24} /></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 bg-gray-50 overflow-x-auto">
          {[
            { id: 'LEADS', icon: Briefcase, label: 'ראשי צוותים' },
            { id: 'ASSISTANTS', icon: Users, label: 'צוותים נלווים' },
            { id: 'STATUSES', icon: List, label: 'ניהול סטטוסים' },
            { id: 'USERS', icon: UserIcon, label: 'משתמשים' },
            { id: 'DATA', icon: Database, label: 'גיבוי ושחזור' },
            { id: 'CLOUD', icon: Cloud, label: 'חיבור ענן' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as TabType); setSearchTerm(''); }}
              className={`flex-1 min-w-[120px] py-4 px-4 font-bold text-sm flex items-center justify-center gap-2 transition-colors ${activeTab === tab.id ? 'bg-white border-b-2 border-primary text-primary' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'}`}
            >
              <tab.icon size={18} /> {tab.label}
            </button>
          ))}
        </div>

        {/* Toolbar */}
        {activeTab !== 'DATA' && (
          <div className="p-4 border-b border-gray-100 flex gap-4 bg-white">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-2.5 text-gray-400 w-5 h-5" />
              <input 
                type="text" placeholder="חיפוש..." 
                className="w-full pl-4 pr-10 py-2 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-primary outline-none transition-all shadow-sm"
                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button onClick={() => handleOpenEdit(activeTab)} className="gap-2 shadow-lg"><Plus size={18} /> הוסף חדש</Button>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto bg-gray-50 p-4">
          
          {/* USERS */}
          {activeTab === 'USERS' && (
            <div className="grid grid-cols-1 gap-3">
              {filterItems(users).map(user => (
                <div key={user.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between hover:shadow-md">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-primary font-bold">{user.name.charAt(0)}</div>
                    <div>
                      <h3 className="font-bold text-gray-900">{user.name}</h3>
                      <div className="text-xs text-gray-500 mt-1">{user.role} | {user.email || 'אין אימייל'}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleDeleteClick(user.id, 'USERS')} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-200"><Trash2 size={18} /></button>
                    <button onClick={() => handleOpenEdit('USERS', user)} className="p-2 text-primary hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-200"><Edit2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* LEADS */}
          {activeTab === 'LEADS' && (
            <div className="grid grid-cols-1 gap-3">
              {filterItems(leads).map(lead => (
                <div key={lead.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between hover:shadow-md">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-amber-50 rounded-full flex items-center justify-center text-amber-700 font-bold">{lead.name.charAt(0)}</div>
                    <div>
                      <h3 className="font-bold text-gray-900">{lead.name}</h3>
                      <div className="text-xs text-gray-500 mt-1 flex items-center gap-2">
                         <span className="flex items-center gap-1"><Phone size={10} /> {lead.phone || '-'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={lead.availabilityStatus || (lead.active ? 'ACTIVE' : 'INACTIVE')} onClick={() => openStatusModal(lead.id, 'LEAD')} />
                    <div className="h-6 w-px bg-gray-200 mx-1"></div>
                    <button onClick={() => handleDeleteClick(lead.id, 'LEADS')} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-200"><Trash2 size={18} /></button>
                    <button onClick={() => handleOpenEdit('LEADS', lead)} className="p-2 text-primary hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-200"><Edit2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ASSISTANTS */}
          {activeTab === 'ASSISTANTS' && (
            <div className="grid grid-cols-1 gap-3">
              {filterItems(assistants).map(assistant => (
                <div key={assistant.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between hover:shadow-md">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 font-bold">{assistant.name.charAt(0)}</div>
                    <div>
                      <h3 className="font-bold text-gray-900">{assistant.name}</h3>
                      <div className="text-xs text-gray-500 mt-1 flex items-center gap-2">
                         <span className="flex items-center gap-1"><Phone size={10} /> {assistant.phone || '-'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={assistant.availabilityStatus || (assistant.active ? 'ACTIVE' : 'INACTIVE')} onClick={() => openStatusModal(assistant.id, 'ASSISTANT')} />
                    <div className="h-6 w-px bg-gray-200 mx-1"></div>
                    <button onClick={() => handleDeleteClick(assistant.id, 'ASSISTANTS')} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-200"><Trash2 size={18} /></button>
                    <button onClick={() => handleOpenEdit('ASSISTANTS', assistant)} className="p-2 text-primary hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-200"><Edit2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* STATUSES */}
          {activeTab === 'STATUSES' && (
            <div className="grid grid-cols-1 gap-3">
               {statuses.map(status => (
                 <div key={status.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between hover:shadow-md">
                    <div className="flex items-center gap-4">
                       <div className={`w-8 h-8 rounded-full border shadow-sm ${THEME_OPTIONS.find(t => t.value === status.color)?.bg}`}></div>
                       <div>
                         <h3 className="font-bold text-lg text-gray-900">{status.name}</h3>
                         <div className="flex gap-1 mt-1">
                           <span className="text-[10px] px-2 py-0.5 bg-gray-100 rounded text-gray-600 border border-gray-200">
                             {status.type === 'ACTIVE' ? 'פעיל' : status.type === 'INACTIVE' ? 'לא פעיל' : 'ניטרלי'}
                           </span>
                           {status.allowedScenes?.map(scene => (
                              <span key={scene} className="text-[10px] px-2 py-0.5 bg-blue-50 rounded text-blue-600 border border-blue-100">
                                {SCENE_OPTIONS.find(s => s.id === scene)?.label || scene}
                              </span>
                           ))}
                         </div>
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleOpenEdit('STATUSES', status)} className="p-2 text-primary hover:bg-blue-50 rounded-lg"><Edit2 size={18} /></button>
                      {!status.isDefault && (
                        <button onClick={() => handleDeleteClick(status.id, 'STATUSES')} className="p-2 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 size={18} /></button>
                      )}
                    </div>
                 </div>
               ))}
            </div>
          )}

          {/* DATA (Backup & Restore) */}
          {activeTab === 'DATA' && (
            <div className="max-w-3xl mx-auto space-y-6">
               <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center gap-4 mb-4">
                     <div className="p-3 bg-blue-50 text-blue-600 rounded-full"><Download size={24} /></div>
                     <div>
                        <h3 className="text-xl font-bold text-gray-900">גיבוי נתונים (ייצוא)</h3>
                        <p className="text-gray-500 text-sm">הורד קובץ גיבוי של כל המידע במערכת למחשב שלך. מומלץ לבצע זאת אחת לשבוע.</p>
                     </div>
                  </div>
                  <Button onClick={handleExportBackup} className="w-full gap-2 text-lg">
                     <Download size={20} /> הורד קובץ גיבוי
                  </Button>
               </div>

               <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center gap-4 mb-4">
                     <div className="p-3 bg-amber-50 text-amber-600 rounded-full"><Upload size={24} /></div>
                     <div>
                        <h3 className="text-xl font-bold text-gray-900">שחזור נתונים (ייבוא)</h3>
                        <p className="text-gray-500 text-sm">טען קובץ גיבוי כדי לשחזר או לעדכן את המערכת. <span className="font-bold text-red-600">שים לב: פעולה זו תדרוס את הנתונים הקיימים!</span></p>
                     </div>
                  </div>
                  <div className="relative">
                     <input 
                       type="file" 
                       accept=".json" 
                       ref={fileInputRef}
                       onChange={handleImportBackup}
                       className="hidden"
                     />
                     <Button onClick={() => fileInputRef.current?.click()} variant="secondary" className="w-full gap-2 text-lg border-dashed border-2 hover:bg-amber-50 hover:border-amber-300">
                        <Upload size={20} /> בחר קובץ לשחזור
                     </Button>
                  </div>
               </div>

               <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-sm text-blue-800">
                  <p className="font-bold mb-1">ℹ️ מידע חשוב על סינכרון:</p>
                  <p>מערכת זו פועלת באופן מקומי. כדי "לסנכרן" נתונים בין מחשבים שונים, יש לבצע <strong>ייצוא</strong> ממחשב אחד, לשלוח את הקובץ למחשב השני, ולבצע שם <strong>ייבוא</strong>.</p>
               </div>
            </div>
          )}

          {/* CLOUD (Firebase Sync) */}
          {activeTab === 'CLOUD' && (
            <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
               <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                       <div className={`p-3 rounded-full ${fullState?.isCloudEnabled ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                         <Cloud size={24} />
                       </div>
                       <div>
                          <h3 className="text-xl font-bold text-gray-900">חיבור ענן (Firebase)</h3>
                          <p className="text-gray-500 text-sm">סנכרן את המשימות שלך לענן לגיבוי בזמן אמת ושיתוף בין מכשירים.</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                       <span className={`text-xs font-bold px-2 py-1 rounded-full ${fullState?.isCloudEnabled ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                         {fullState?.isCloudEnabled ? 'מחובר' : 'לא מחובר'}
                       </span>
                       <button 
                         onClick={() => onToggleCloud?.(!fullState?.isCloudEnabled)}
                         className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${fullState?.isCloudEnabled ? 'bg-primary' : 'bg-gray-200'}`}
                       >
                         <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${fullState?.isCloudEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                       </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Firebase API Key</label>
                        <input 
                          type="password"
                          className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none"
                          value={tempFirebaseConfig.apiKey}
                          onChange={(e) => setTempFirebaseConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                          placeholder="AIzaSy..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Project ID</label>
                        <input 
                          type="text"
                          className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none"
                          value={tempFirebaseConfig.projectId}
                          onChange={(e) => setTempFirebaseConfig(prev => ({ ...prev, projectId: e.target.value }))}
                          placeholder="my-project-123"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Auth Domain (Optional)</label>
                        <input 
                          type="text"
                          className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none"
                          value={tempFirebaseConfig.authDomain || ''}
                          onChange={(e) => setTempFirebaseConfig(prev => ({ ...prev, authDomain: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">App ID (Optional)</label>
                        <input 
                          type="text"
                          className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none"
                          value={tempFirebaseConfig.appId || ''}
                          onChange={(e) => setTempFirebaseConfig(prev => ({ ...prev, appId: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button 
                        onClick={() => {
                          if (!tempFirebaseConfig.apiKey || !tempFirebaseConfig.projectId) {
                            return alert('נא להזין לפחות API Key ו-Project ID');
                          }
                          onUpdateFirebaseConfig?.(tempFirebaseConfig);
                          alert('הגדרות ענן עודכנו בהצלחה');
                        }}
                        className="w-full gap-2"
                      >
                        <Save size={18} /> שמור הגדרות חיבור
                      </Button>
                    </div>
                  </div>
               </div>

               <div className="bg-amber-50 p-4 rounded-lg border border-amber-100 text-sm text-amber-800 space-y-2">
                  <p className="font-bold flex items-center gap-2">
                    <ShieldAlert size={16} /> שים לב:
                  </p>
                  <p>השימוש ב-Firebase דורש הגדרת פרויקט ב-Google Cloud Console. וודא ש-Firestore Database מופעל ושהרשאות הגישה מוגדרות כראוי.</p>
                  <p>לאחר הגדרת החיבור והפעלתו, כל שינוי במשימות יסונכרן אוטומטית לענן.</p>
               </div>
            </div>
          )}
        </div>

        {/* --- EDIT MODAL --- */}
        {isEditing && (
          <div className="absolute inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animation-fade-in flex flex-col max-h-[90vh]">
              <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center shrink-0">
                <h3 className="font-bold text-lg text-gray-800">
                   {editType === 'STATUSES' ? 'עריכת סטטוס' : editType === 'LEADS' ? 'עריכת ראש צוות' : editType === 'ASSISTANTS' ? 'עריכת איש צוות' : 'עריכת משתמש'}
                </h3>
                <button onClick={() => setIsEditing(false)} className="text-gray-500 hover:text-gray-800"><X size={20} /></button>
              </div>
              
              <div className="p-6 space-y-4 overflow-y-auto">
                
                {/* 1. USERS FORM */}
                {editType === 'USERS' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">שם מלא</label>
                      <input 
                        type="text" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempUser.name || ''} onChange={e => setTempUser({...tempUser, name: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">תפקיד</label>
                      <select 
                        className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempUser.role || 'USER'} onChange={e => setTempUser({...tempUser, role: e.target.value as any})}
                      >
                        <option value="ADMIN">מנהל מערכת</option>
                        <option value="MANAGER">מנהל עבודה</option>
                        <option value="TEAM_LEAD">ראש צוות</option>
                        <option value="USER">צופה בלבד</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">טלפון</label>
                      <input 
                        type="tel" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempUser.phone || ''} onChange={e => setTempUser({...tempUser, phone: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">אימייל</label>
                      <input 
                        type="email" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempUser.email || ''} onChange={e => setTempUser({...tempUser, email: e.target.value})} 
                      />
                    </div>
                  </>
                )}

                {/* 2. LEADS FORM */}
                {editType === 'LEADS' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">שם ראש הצוות</label>
                      <input 
                        type="text" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempLead.name || ''} onChange={e => setTempLead({...tempLead, name: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">טלפון</label>
                      <input 
                        type="tel" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempLead.phone || ''} onChange={e => setTempLead({...tempLead, phone: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">קישור למשתמש מערכת</label>
                      <select 
                        className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempLead.linkedUserId || ''} onChange={e => setTempLead({...tempLead, linkedUserId: e.target.value})}
                      >
                        <option value="">-- ללא קישור --</option>
                        {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                      </select>
                    </div>
                    <div>
                       <label className="block text-sm font-medium text-gray-700 mb-1">הערות</label>
                       <textarea 
                          className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm" rows={2}
                          value={tempLead.notes || ''} onChange={e => setTempLead({...tempLead, notes: e.target.value})}
                       />
                    </div>
                  </>
                )}

                {/* 3. ASSISTANTS FORM */}
                {editType === 'ASSISTANTS' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">שם איש הצוות</label>
                      <input 
                        type="text" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempAssistant.name || ''} onChange={e => setTempAssistant({...tempAssistant, name: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">טלפון</label>
                      <input 
                        type="tel" className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempAssistant.phone || ''} onChange={e => setTempAssistant({...tempAssistant, phone: e.target.value})} 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">ראש צוות ברירת מחדל</label>
                      <select 
                        className="w-full border border-gray-300 bg-white rounded-lg p-2 focus:ring-2 focus:ring-primary outline-none shadow-sm"
                        value={tempAssistant.leadId || ''} onChange={e => setTempAssistant({...tempAssistant, leadId: e.target.value})}
                      >
                        <option value="">-- בחר --</option>
                        {leads.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                      </select>
                    </div>
                  </>
                )}
                
                {/* 4. STATUSES FORM */}
                {editType === 'STATUSES' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">שם הסטטוס</label>
                      <input type="text" className="w-full border border-gray-300 bg-white rounded-lg p-2 shadow-sm" value={tempStatus.name || ''} onChange={e => setTempStatus({...tempStatus, name: e.target.value})} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">סוג סטטוס</label>
                        <select 
                           className="w-full border border-gray-300 bg-white rounded-lg p-2 shadow-sm"
                           value={tempStatus.type || 'ACTIVE'} 
                           onChange={e => setTempStatus({...tempStatus, type: e.target.value as any})}
                        >
                           <option value="ACTIVE">פעיל</option>
                           <option value="INACTIVE">לא פעיל / סיום</option>
                           <option value="NEUTRAL">ניטרלי / טיוטה</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">ערכת צבעים</label>
                      <div className="grid grid-cols-5 gap-2">
                        {THEME_OPTIONS.map(theme => (
                          <button
                            key={theme.value}
                            onClick={() => setTempStatus({ ...tempStatus, color: theme.value })}
                            className={`w-10 h-10 rounded-full border-2 transition-all ${theme.bg} ${tempStatus.color === theme.value ? 'border-black ring-2 ring-offset-2 ring-gray-300' : 'border-transparent'}`}
                            title={theme.label}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">שיוך לסצנות</label>
                      <div className="flex flex-wrap gap-2">
                         {SCENE_OPTIONS.map(scene => (
                            <button
                               key={scene.id}
                               onClick={() => toggleScene(scene.id)}
                               className={`px-3 py-1.5 rounded-lg text-sm border transition-all ${
                                  tempStatus.allowedScenes?.includes(scene.id) 
                                  ? 'bg-primary text-white border-primary' 
                                  : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
                               }`}
                            >
                               {scene.label}
                            </button>
                         ))}
                      </div>
                    </div>
                  </>
                )}

              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end gap-3 shrink-0">
                <Button variant="ghost" onClick={() => setIsEditing(false)}>ביטול</Button>
                <Button onClick={handleSave} className="gap-2"><Save size={18} /> שמור</Button>
              </div>
            </div>
          </div>
        )}

        {/* --- AVAILABILITY MODAL --- */}
        {isStatusModalOpen && (
          <div className="absolute inset-0 z-[70] bg-black/40 flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden p-6 space-y-6 animate-in fade-in zoom-in duration-200">
                <h3 className="text-xl font-black text-center text-gray-800 border-b pb-4">עדכון סטטוס זמינות</h3>
                
                <div className="space-y-3">
                   {/* 1. Active */}
                   <button onClick={() => handleSetAvailability('ACTIVE')} className="w-full flex items-center justify-between p-4 bg-green-50 hover:bg-green-100 border border-green-200 rounded-xl transition-all group">
                      <div className="flex items-center gap-3">
                         <div className="p-2 bg-green-200 text-green-700 rounded-full"><CheckCircle size={20} /></div>
                         <div className="text-right">
                            <div className="font-bold text-green-900">פעיל וזמין</div>
                            <div className="text-xs text-green-600">משובץ לסידור עבודה</div>
                         </div>
                      </div>
                   </button>

                   {/* 2. Disable Group */}
                   <div className="border border-red-100 rounded-xl overflow-hidden">
                      <div className="bg-red-50 p-3 text-red-800 font-bold text-sm border-b border-red-100 flex items-center gap-2">
                         <Power size={16} /> אפשרויות השבתה (לא זמין)
                      </div>
                      <div className="divide-y divide-red-100">
                         <button onClick={() => handleSetAvailability('SICK')} className="w-full flex items-center gap-3 p-3 bg-white hover:bg-red-50 transition-colors text-right">
                            <div className="p-1.5 bg-red-100 text-red-600 rounded-lg"><Thermometer size={18} /></div>
                            <span className="font-medium text-gray-700">מחלה</span>
                         </button>
                         <button onClick={() => handleSetAvailability('VACATION')} className="w-full flex items-center gap-3 p-3 bg-white hover:bg-blue-50 transition-colors text-right">
                            <div className="p-1.5 bg-blue-100 text-blue-600 rounded-lg"><Plane size={18} /></div>
                            <span className="font-medium text-gray-700">חופשה</span>
                         </button>
                         <button onClick={() => handleSetAvailability('INACTIVE')} className="w-full flex items-center gap-3 p-3 bg-white hover:bg-gray-50 transition-colors text-right">
                            <div className="p-1.5 bg-gray-100 text-gray-600 rounded-lg"><Power size={18} /></div>
                            <span className="font-medium text-gray-700">מושבת כללי</span>
                         </button>
                      </div>
                   </div>
                </div>
                
                <button onClick={() => setIsStatusModalOpen(false)} className="w-full py-3 text-gray-500 hover:text-gray-800 font-bold bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                   ביטול
                </button>
             </div>
          </div>
        )}

        {/* --- DELETE CONFIRMATION MODAL --- */}
        {deleteConfirm && (
          <div className="absolute inset-0 z-[100] bg-black/60 flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6 text-center animate-in fade-in zoom-in duration-200 border-t-4 border-red-600">
                <div className="w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-red-100">
                   <Trash2 size={32} />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">מחיקת פריט</h3>
                <p className="text-gray-600 mb-8 leading-relaxed">
                   האם אתה בטוח שברצונך למחוק את 
                   <br/>
                   <span className="font-bold text-gray-900 bg-red-50 px-2 py-0.5 rounded mx-1">{deleteConfirm.name}</span>?
                   <br/>
                   <span className="text-xs text-red-500 font-bold mt-2 block">פעולה זו אינה הפיכה!</span>
                </p>
                <div className="flex gap-3">
                   <Button variant="ghost" onClick={() => setDeleteConfirm(null)} className="flex-1 font-bold">ביטול</Button>
                   <Button variant="danger" onClick={confirmDelete} className="flex-1 shadow-lg shadow-red-200">מחק לצמיתות</Button>
                </div>
             </div>
          </div>
        )}

      </div>
    </div>
  );
};
