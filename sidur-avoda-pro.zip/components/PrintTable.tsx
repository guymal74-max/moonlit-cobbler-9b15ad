
import React from 'react';
import { JobEntry } from '../types';
import { format } from 'date-fns';
import { he } from 'date-fns/locale';
import { formatTime24h } from '../utils/timeUtils';

interface PrintTableProps {
  date: string;
  jobs: JobEntry[];
}

export const PrintTable: React.FC<PrintTableProps> = ({ date, jobs }) => {
  const operations = jobs.filter(j => j.type === 'OPERATIONS');
  const projects = jobs.filter(j => j.type === 'PROJECTS');

  const formattedDate = format(new Date(date), 'dd/MM/yyyy', { locale: he });
  const dayName = format(new Date(date), 'EEEE', { locale: he });

  const renderRow = (job: JobEntry | any, index: number, sectionOffset: number) => {
    const isEmpty = !job.teamLead;
    return (
      <tr key={job.id} className="h-28 text-right border-black font-sans break-inside-avoid">
        
        {/* 1. Team Lead & Team */}
        <td className="border border-black p-2 w-[12%] align-top text-center">
           <div className="font-bold underline mb-1 text-sm">{job.teamLead}</div>
           <div className="text-[12px] leading-tight font-medium">
             {job.teamMembers?.join(', ')}
           </div>
        </td>

        {/* 2. Customer Name */}
        <td className="border border-black p-2 w-[12%] align-middle text-center font-bold text-sm">
          <div>{job.customerName}</div>
          {(job.branchName || job.branchNumber) && (
            <div className="text-[10px] mt-1 font-normal bg-gray-100 p-1 rounded">
              סניף: {job.branchName} {job.branchNumber ? `(${job.branchNumber})` : ''}
            </div>
          )}
        </td>

        {/* 3. Address / Location */}
        <td className="border border-black p-2 w-[12%] align-middle text-center font-bold text-sm">
          {job.location}
        </td>

        {/* 4. Order Number */}
        <td className="border border-black p-2 w-[8%] align-middle text-center font-black text-lg">
          {job.projectNumber}
        </td>

        {/* 5. Description & Platform */}
        <td className="border border-black p-2 w-[25%] align-top">
           <div className="flex items-center justify-between mb-1">
             <div className="font-bold text-sm leading-tight">{job.description}</div>
             {job.faultType && <div className="text-[9px] bg-gray-200 px-1 rounded font-black">{job.faultType}</div>}
           </div>
           {job.platformTypes && job.platformTypes.length > 0 && (
             <div className="flex gap-1 mt-2">
               {job.platformTypes.map(type => (
                 <div key={type} className="inline-block px-2 py-0.5 border border-black text-[10px] font-black rounded-sm bg-white">
                   {type === 'BAMA' ? '🏗️ במה' : '🛑 עמדה'}
                 </div>
               ))}
             </div>
           )}
           <div className="mt-2 text-[10px] text-gray-500">{isEmpty ? '' : `${formatTime24h(job.startTime)} - ${formatTime24h(job.endTime)}`}</div>
        </td>

        {/* 6. Warehouse Equipment / Notes */}
        <td className="border border-black p-2 w-[20%] align-top text-xs bg-gray-50">
           {job.machsanEquipment && (
            <div className="mb-2 border-b border-gray-400 pb-2">
              <span className="font-black underline block mb-1">ציוד מהמחסן:</span> 
              <span className="font-bold text-primary">{job.machsanEquipment}</span>
            </div>
          )}
          {job.notes && (
             <div className="mb-1 italic">
                <span className="font-bold underline not-italic">הערות:</span> {job.notes}
             </div>
          )}
          {(job.contactName || job.contactPhone) && (
            <div className="mt-2 font-black border-t-2 border-gray-400 pt-1 text-[10px]">
              איש קשר: {job.contactName} {job.contactPhone ? `| ${job.contactPhone}` : ''}
            </div>
          )}
        </td>

        {/* 7. Status */}
        <td className="border border-black p-2 w-[11%] align-middle text-center font-bold">
           {job.status}
        </td>
      </tr>
    );
  };

  const fillEmpty = (current: any[], min: number) => {
    const arr = [...current];
    while (arr.length < min) arr.push({ id: `empty-${arr.length}` });
    return arr;
  };

  return (
    <div className="w-full bg-white text-black p-4 mx-auto print-container" dir="rtl">
      {/* Print Header (Visible only in print) */}
      <div className="print-header print-only">
        רפי שפירא ובניו בע"מ
      </div>

      {/* Header */}
      <div className="flex justify-between items-center border-b-8 border-primary mb-6 pb-2">
        <div className="text-right">
           <div className="text-5xl font-black text-primary tracking-tighter leading-none">רפי שפירא</div>
           <div className="text-sm font-bold text-gray-700 tracking-[0.2em] pr-1 uppercase">GROUP</div>
        </div>
        
        <div className="text-center">
            <h1 className="text-4xl font-black underline mb-1">סידור עבודה יומי</h1>
            <div className="text-xl font-bold border-4 border-black px-6 py-1 rounded-full inline-block mt-2">
              יום {dayName} | {formattedDate}
            </div>
        </div>

        <div className="text-left flex flex-col items-center border-4 border-primary p-2 rounded-2xl bg-red-50">
           <div className="text-[10px] font-black uppercase text-primary mb-1">סה"כ צוותים מבצעים</div>
           <div className="text-5xl font-black leading-none text-red-900">{jobs.length}</div>
        </div>
      </div>

      <table className="w-full border-collapse border-4 border-black table-fixed">
        <thead>
          <tr className="bg-primary text-white text-sm">
            <th className="border border-black py-3 w-[12%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>ראש צוות</th>
            <th className="border border-black py-3 w-[12%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>לקוח</th>
            <th className="border border-black py-3 w-[12%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>כתובת</th>
            <th className="border border-black py-3 w-[8%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>מס' הזמנה</th>
            <th className="border border-black py-3 w-[25%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>תיאור העבודה</th>
            <th className="border border-black py-3 w-[20%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>ציוד מהמחסן</th>
            <th className="border border-black py-3 w-[11%] font-black text-white" style={{ backgroundColor: '#b91c1c !important', color: 'white !important', WebkitPrintColorAdjust: 'exact' }}>סטטוס</th>
          </tr>
        </thead>
        <tbody>
          {/* Operations */}
          <tr className="bg-red-50 h-10 border-y-2 border-black" style={{ backgroundColor: '#fef2f2 !important', WebkitPrintColorAdjust: 'exact' }}>
            <td colSpan={7} className="border border-black px-4 font-black text-primary text-xl tracking-wider">
              משימות תפעול ושירות
            </td>
          </tr>
          {fillEmpty(operations, 6).map((job, i) => renderRow(job, i, 0))}

          {/* Projects */}
          <tr className="bg-amber-100 h-10 border-t-4 border-black border-b-2" style={{ backgroundColor: '#fef3c7 !important', WebkitPrintColorAdjust: 'exact' }}>
            <td colSpan={7} className="border border-black px-4 font-black text-amber-800 text-xl tracking-wider">
              פרויקטים והתקנות
            </td>
          </tr>
          {fillEmpty(projects, 3).map((job, i) => renderRow(job, i, operations.length || 6))}
        </tbody>
      </table>

      {/* Footer Signatures */}
      <div className="mt-10 flex justify-between px-12 text-sm break-inside-avoid">
         <div className="flex gap-20">
            <div className="space-y-8">
               <div className="font-black flex items-end gap-3">
                  חתימת מנהל עבודה: <div className="w-56 border-b-2 border-black h-1"></div>
               </div>
            </div>
            <div className="space-y-8">
               <div className="font-black flex items-end gap-3">
                  חתימת ראש צוות: <div className="w-56 border-b-2 border-black h-1"></div>
               </div>
            </div>
         </div>
         <div className="flex flex-col items-end justify-end text-gray-500 font-mono text-[10px]">
            <div>Sidur Avoda Pro v2.3</div>
         </div>
      </div>
      <div className="print-footer print-only">
        תאריך הדפסה: {format(new Date(), 'dd/MM/yyyy HH:mm')}
      </div>
    </div>
  );
};
