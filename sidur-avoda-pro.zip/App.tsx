
import React, { useState, useEffect, useRef } from 'react';
import { format, addDays } from 'date-fns';
import { he } from 'date-fns/locale';
import { Printer, Plus, ChevronRight, ChevronLeft, Layout, Table as TableIcon, FileSpreadsheet, Settings, Filter, Search, MessageCircle, ZoomIn, ZoomOut } from 'lucide-react';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, setDoc, deleteDoc, onSnapshot, collection, query } from 'firebase/firestore';
import { AppState, JobEntry, INITIAL_STATE, Backup, INITIAL_STATUSES, StatusDefinition, INITIAL_FAULT_TYPES, FirebaseConfig, CustomerMemory } from './types';
import { JobForm } from './components/JobForm';
import { PrintTable } from './components/PrintTable';
import { WeeklyView } from './components/WeeklyView';
import { JobCard } from './components/JobCard';
import { Button } from './components/ui/Button';
import { AdminPanel } from './components/AdminPanel';
import { exportToExcel } from './utils/excelExport';
import { ScheduleSenderModal } from './components/ScheduleSenderModal';

const STORAGE_KEY_V2 = 'sidur_avoda_state_v2';
const BACKUP_INTERVAL_MS = 60 * 60 * 1000; // 1 Hour
const UPDATES_THRESHOLD_FOR_BACKUP = 50;

export default function App() {
  // Core Unified State
  const [state, setState] = useState<AppState>(INITIAL_STATE);
  
  // UI State
  const [currentDate, setCurrentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<JobEntry | undefined>(undefined);
  const [viewMode, setViewMode] = useState<'DAILY' | 'WEEKLY'>('DAILY');
  const [selectedLeadFilter, setSelectedLeadFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isScheduleSenderOpen, setIsScheduleSenderOpen] = useState(false);
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(() => {
    const saved = localStorage.getItem('zoom_level');
    return saved ? parseInt(saved, 10) : 100;
  });

  useEffect(() => {
    localStorage.setItem('zoom_level', zoomLevel.toString());
  }, [zoomLevel]);

  // Firebase Initialization
  const getFirebaseDb = () => {
    if (!state.isCloudEnabled || !state.firebaseConfig?.apiKey || !state.firebaseConfig?.projectId) return null;
    try {
      const apps = getApps();
      const app = apps.length > 0 ? apps[0] : initializeApp(state.firebaseConfig);
      return getFirestore(app);
    } catch (e) {
      console.error('Firebase init error:', e);
      return null;
    }
  };

  const syncToCloud = async (job: JobEntry, isDelete = false) => {
    const db = getFirebaseDb();
    if (!db) return;
    setIsSyncing(true);
    try {
      const docRef = doc(db, 'jobs', job.id);
      if (isDelete) {
        await deleteDoc(docRef);
      } else {
        await setDoc(docRef, job);
      }
    } catch (e) {
      console.error('Cloud sync error:', e);
    } finally {
      setIsSyncing(false);
    }
  };

  // Real-time Cloud Sync Listener
  useEffect(() => {
    const db = getFirebaseDb();
    if (!db || !state.isCloudEnabled) return;

    const q = query(collection(db, 'jobs'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const cloudJobs: JobEntry[] = [];
      snapshot.forEach((doc) => {
        cloudJobs.push(doc.data() as JobEntry);
      });

      if (cloudJobs.length > 0 || snapshot.empty) {
        setState(prev => {
          // Only update if tasks are actually different to avoid loops
          const cloudIds = cloudJobs.map(j => j.id).sort().join(',');
          const localIds = prev.tasks.map(j => j.id).sort().join(',');
          
          if (cloudIds === localIds) {
            // Check if any job content changed
            const hasChanges = cloudJobs.some(cj => {
              const lj = prev.tasks.find(t => t.id === cj.id);
              return !lj || JSON.stringify(cj) !== JSON.stringify(lj);
            });
            if (!hasChanges) return prev;
          }

          return {
            ...prev,
            tasks: cloudJobs
          };
        });
      }
    }, (error) => {
      console.error("Firestore listener error:", error);
    });

    return () => unsubscribe();
  }, [state.isCloudEnabled, state.firebaseConfig]);
  const [advancedFilters, setAdvancedFilters] = useState({
    customerName: '',
    projectNumber: '',
    platformType: 'ALL',
    faultType: 'ALL',
    status: 'ALL',
    date: ''
  });

  // Backup Logic Refs
  const updatesCountRef = useRef(0);

  // Load Data
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY_V2);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Migration: Ensure jobStatuses exists
      if (!parsed.jobStatuses || parsed.jobStatuses.length === 0) {
        parsed.jobStatuses = INITIAL_STATUSES;
      }
      if (!parsed.faultTypes || parsed.faultTypes.length === 0) {
        parsed.faultTypes = INITIAL_FAULT_TYPES;
      }
      // Migration: platformType to platformTypes
      if (parsed.tasks) {
        parsed.tasks = parsed.tasks.map((j: any) => {
          if (j.platformType && (!j.platformTypes || j.platformTypes.length === 0)) {
            return { ...j, platformTypes: [j.platformType] };
          }
          if (!j.platformTypes) return { ...j, platformTypes: [] };
          return j;
        });
      }

      // Ensure Firebase config from INITIAL_STATE is applied if missing or disabled
      if (!parsed.firebaseConfig || !parsed.firebaseConfig.apiKey) {
        parsed.firebaseConfig = INITIAL_STATE.firebaseConfig;
        parsed.isCloudEnabled = INITIAL_STATE.isCloudEnabled;
      }

      setState(parsed);
    }
  }, []);

  // Save Data
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(state));
  }, [state]);

  // Automatic Hourly Backup
  useEffect(() => {
    const intervalId = setInterval(() => {
      createBackup('Hourly Auto Backup');
    }, BACKUP_INTERVAL_MS);

    return () => clearInterval(intervalId);
  }, []);

  const createBackup = (description: string) => {
    setState(prevState => {
      const newBackup: Backup = {
        backup_id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        description,
        full_state: JSON.parse(JSON.stringify(prevState)) // Deep copy of current state
      };

      // Keep only last 20 backups to prevent storage overflow
      const updatedBackups = [newBackup, ...(prevState.backups || [])].slice(0, 20);
      
      return {
        ...prevState,
        backups: updatedBackups
      };
    });
  };

  const incrementUpdateAndCheckBackup = () => {
    updatesCountRef.current += 1;
    if (updatesCountRef.current >= UPDATES_THRESHOLD_FOR_BACKUP) {
      createBackup(`Auto Backup after ${UPDATES_THRESHOLD_FOR_BACKUP} updates`);
      updatesCountRef.current = 0;
    }
  };

  const handleRestoreState = (newState: AppState) => {
    if (window.confirm('פעולה זו תדרוס את הנתונים הנוכחיים ותשחזר את המערכת מהקובץ שנבחר. האם להמשיך?')) {
      setState(newState);
      alert('שחזור המערכת בוצע בהצלחה.');
      setIsAdminOpen(false);
    }
  };

  const handleSaveJob = (job: JobEntry) => {
    // Conflict check for multi-user
    if (editingJob && state.isCloudEnabled) {
      const currentInState = state.tasks.find(t => t.id === job.id);
      if (currentInState && JSON.stringify(currentInState) !== JSON.stringify(editingJob)) {
        const confirmOverwrite = window.confirm('שים לב: הזמנה זו עודכנה על ידי משתמש אחר בזמן שערכת אותה. האם ברצונך לשמור את השינויים שלך ולדרוס את העדכון שלהם?');
        if (!confirmOverwrite) return;
      }
    }

    setState(prev => {
      const exists = prev.tasks.find(j => j.id === job.id);
      let newTasks;
      if (exists) {
        newTasks = prev.tasks.map(j => j.id === job.id ? job : j);
      } else {
        newTasks = [...prev.tasks, job];
      }

      // Update Customer Memory
      const newMemory: CustomerMemory = { ...(prev.customerMemory || {}) };
      if (job.customerName) {
        const customer = newMemory[job.customerName] || { branches: {} };
        if (job.branchName) {
          customer.branches[job.branchName] = {
            branchName: job.branchName,
            branchNumber: job.branchNumber || '',
            location: job.location || '',
            contactName: job.contactName || '',
            contactPhone: job.contactPhone || ''
          };
          customer.lastUsedBranch = job.branchName;
        }
        newMemory[job.customerName] = customer;
      }

      return { ...prev, tasks: newTasks, customerMemory: newMemory };
    });
    
    syncToCloud(job);
    incrementUpdateAndCheckBackup();
    setIsModalOpen(false);
    setEditingJob(undefined);
  };

  const handleDeleteJob = (id: string) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק משימה זו?')) {
      const jobToDelete = state.tasks.find(j => j.id === id);
      setState(prev => ({
        ...prev,
        tasks: prev.tasks.filter(j => j.id !== id)
      }));
      if (jobToDelete) syncToCloud(jobToDelete, true);
      incrementUpdateAndCheckBackup();
    }
  };

  const handleEditJob = (job: JobEntry) => {
    setEditingJob(job);
    setIsModalOpen(true);
  };

  // Filter Logic for Display
  const getFilteredJobs = () => {
    let filtered = state.tasks;
    
    // Advanced Filters
    if (showAdvancedSearch) {
      if (advancedFilters.customerName) {
        filtered = filtered.filter(j => j.customerName?.toLowerCase().includes(advancedFilters.customerName.toLowerCase()));
      }
      if (advancedFilters.projectNumber) {
        filtered = filtered.filter(j => j.projectNumber?.toLowerCase().includes(advancedFilters.projectNumber.toLowerCase()));
      }
      if (advancedFilters.platformType !== 'ALL') {
        filtered = filtered.filter(j => j.platformTypes?.includes(advancedFilters.platformType as any));
      }
      if (advancedFilters.faultType !== 'ALL') {
        filtered = filtered.filter(j => j.faultType === advancedFilters.faultType);
      }
      if (advancedFilters.status !== 'ALL') {
        filtered = filtered.filter(j => j.status === advancedFilters.status);
      }
      if (advancedFilters.date) {
        filtered = filtered.filter(j => j.date === advancedFilters.date);
      }
    } else {
      // Simple Search Filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        filtered = filtered.filter(j => 
          j.projectNumber?.toLowerCase().includes(q) ||
          j.customerName?.toLowerCase().includes(q) ||
          j.branchName?.toLowerCase().includes(q) ||
          j.location?.toLowerCase().includes(q)
        );
      }

      // Date Filter (for Daily view)
      if (viewMode === 'DAILY' && !searchQuery.trim()) {
        filtered = filtered.filter(j => j.date === currentDate);
      }
    }
    
    // Team Lead Filter
    if (selectedLeadFilter !== 'ALL') {
      filtered = filtered.filter(j => j.teamLead === selectedLeadFilter);
    }

    // Sort: Date desc, then Status
    return filtered.sort((a, b) => {
      if (a.date !== b.date) return new Date(b.date).getTime() - new Date(a.date).getTime();
      return a.status.localeCompare(b.status);
    });
  };

  const displayJobs = getFilteredJobs();
  const operationsJobs = displayJobs.filter(j => j.type === 'OPERATIONS');
  const projectJobs = displayJobs.filter(j => j.type === 'PROJECTS');

  // Helper to update statuses
  const handleUpdateStatuses = (newStatuses: StatusDefinition[]) => {
    setState(prev => ({ ...prev, jobStatuses: newStatuses }));
  };

  const handleUpdateFaultTypes = (newFaultTypes: string[]) => {
    setState(prev => ({ ...prev, faultTypes: newFaultTypes }));
  };

  const suggestions = searchQuery.trim() ? Array.from(new Set(
    state.tasks
      .filter(j => 
        j.projectNumber?.toLowerCase().startsWith(searchQuery.toLowerCase()) ||
        j.customerName?.toLowerCase().startsWith(searchQuery.toLowerCase()) ||
        j.branchName?.toLowerCase().startsWith(searchQuery.toLowerCase())
      )
      .map(j => {
        if (j.projectNumber?.toLowerCase().startsWith(searchQuery.toLowerCase())) return j.projectNumber;
        if (j.customerName?.toLowerCase().startsWith(searchQuery.toLowerCase())) return j.customerName;
        return j.branchName;
      })
  )).slice(0, 5) : [];

  return (
    <>
      <div className="screen-only print:hidden min-h-screen bg-gray-50 pb-24 md:pb-20">
        
        {/* Navigation */}
        <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:justify-between md:h-16 py-2 md:py-0 gap-2 md:gap-0">
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <button 
                     onClick={() => setIsAdminOpen(true)}
                     className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors relative"
                     title="הגדרות וניהול"
                   >
                     <Settings size={20} />
                     {state.isCloudEnabled && (
                       <>
                         <div className={`absolute top-1 right-1 w-2 h-2 rounded-full border border-white ${getFirebaseDb() ? 'bg-green-500' : 'bg-red-500'}`} />
                         {isSyncing && (
                           <div className="absolute -bottom-1 -right-1 text-[8px] font-bold text-primary animate-pulse bg-white px-1 rounded shadow-sm border border-gray-100 whitespace-nowrap">
                             מסתנכרן...
                           </div>
                         )}
                       </>
                     )}
                   </button>

                   <div className="flex items-center bg-gray-100 rounded-lg p-1 gap-1">
                     <button 
                       onClick={() => setZoomLevel(prev => Math.max(70, prev - 10))}
                       className="p-1 hover:bg-white rounded-md transition-all text-gray-600"
                       title="הקטן תצוגה"
                     >
                       <ZoomOut size={14} />
                     </button>
                     <span className="text-[10px] font-bold text-gray-500 min-w-[24px] text-center">{zoomLevel}%</span>
                     <button 
                       onClick={() => setZoomLevel(prev => Math.min(130, prev + 10))}
                       className="p-1 hover:bg-white rounded-md transition-all text-gray-600"
                       title="הגדל תצוגה"
                     >
                       <ZoomIn size={14} />
                     </button>
                   </div>

                   <div className="flex flex-col">
                      <h1 className="text-xl md:text-2xl font-black text-primary tracking-tight truncate">רפי שפירא</h1>
                      <span className="text-[10px] text-gray-500 font-bold tracking-widest leading-none">GROUP</span>
                   </div>
                </div>
                
                <div className="flex bg-gray-100 rounded-lg p-1 md:ml-4">
                  <button onClick={() => setViewMode('DAILY')} className={`p-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${viewMode === 'DAILY' ? 'bg-white shadow text-primary' : 'text-gray-600'}`}>
                    <TableIcon size={16} /> <span className="hidden md:inline">יומי</span>
                  </button>
                  <button onClick={() => setViewMode('WEEKLY')} className={`p-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${viewMode === 'WEEKLY' ? 'bg-white shadow text-primary' : 'text-gray-600'}`}>
                    <Layout size={16} /> <span className="hidden md:inline">שבועי</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-2 md:gap-4">
                {/* Filter Dropdown */}
                <div className="relative">
                   <select 
                      className="appearance-none bg-gray-50 border border-gray-300 text-gray-700 py-1.5 pl-8 pr-4 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                      value={selectedLeadFilter}
                      onChange={(e) => setSelectedLeadFilter(e.target.value)}
                   >
                     <option value="ALL">כל הצוותים</option>
                     {state.teamLeads.filter(l => l.active).map(l => (
                       <option key={l.id} value={l.name}>{l.name}</option>
                     ))}
                   </select>
                   <Filter className="absolute left-2 top-2 text-gray-400 w-4 h-4 pointer-events-none" />
                </div>

                {viewMode === 'DAILY' && (
                  <div className="flex flex-1 md:flex-none items-center justify-between bg-gray-50 rounded-md border border-gray-200 p-1 w-full md:w-auto">
                    {/* Replaced subDays with addDays(-1) */}
                    <button onClick={() => setCurrentDate(prev => addDays(new Date(prev), -1).toISOString().split('T')[0])} className="p-2 hover:bg-gray-200 rounded">
                      <ChevronRight size={20} />
                    </button>
                    <div className="px-2 font-bold text-base text-gray-800">
                      {format(new Date(currentDate), 'dd/MM/yyyy')}
                    </div>
                    <button onClick={() => setCurrentDate(prev => addDays(new Date(prev), 1).toISOString().split('T')[0])} className="p-2 hover:bg-gray-200 rounded">
                      <ChevronLeft size={20} />
                    </button>
                  </div>
                )}
                
                <div className="hidden md:flex gap-2">
                  <Button 
                    onClick={() => exportToExcel(currentDate, state.tasks)} 
                    variant="secondary" 
                    className="gap-2 text-green-700 hover:bg-green-50"
                  >
                    <FileSpreadsheet size={18} />
                  </Button>
                  <Button 
                    onClick={() => setIsScheduleSenderOpen(true)}
                    variant="secondary"
                    className="gap-2 text-green-600 hover:bg-green-50"
                  >
                    <MessageCircle size={18} />
                    <span className="hidden lg:inline">שלח סידור</span>
                  </Button>
                  <Button 
                     onClick={() => window.print()} 
                     className="gap-2 bg-[#c61d23] hover:bg-[#a6181d] text-white shadow-sm"
                     title="הדפס סידור עבודה"
                  >
                    <Printer size={18} />
                  </Button>
                  <Button onClick={() => { setEditingJob(undefined); setIsModalOpen(true); }} className="gap-2">
                    <Plus size={18} />
                    חדש
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8">
          
          {/* Search & Advanced Filters */}
          <div className="mb-6 space-y-4">
            <div className="relative flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute right-4 top-3.5 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  className="w-full bg-white border border-gray-300 rounded-2xl pr-12 pl-4 py-3.5 text-lg focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none shadow-sm transition-all"
                  placeholder="חיפוש מהיר..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setShowSuggestions(true);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  disabled={showAdvancedSearch}
                />
              </div>
              <Button 
                variant={showAdvancedSearch ? "primary" : "outline"}
                onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
                className="rounded-2xl px-6 gap-2 shrink-0"
              >
                <Filter size={20} />
                <span className="hidden md:inline">חיפוש מתקדם</span>
              </Button>
            </div>
            
            {showAdvancedSearch && (
              <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-lg animate-in fade-in slide-in-from-top-4 duration-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">שם לקוח</label>
                    <input 
                      type="text"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none"
                      value={advancedFilters.customerName}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, customerName: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">מספר הזמנה</label>
                    <input 
                      type="text"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none"
                      value={advancedFilters.projectNumber}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, projectNumber: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">תאריך</label>
                    <input 
                      type="date"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none"
                      value={advancedFilters.date}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, date: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">סטטוס</label>
                    <select 
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none bg-white"
                      value={advancedFilters.status}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, status: e.target.value }))}
                    >
                      <option value="ALL">הכל</option>
                      {state.jobStatuses.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">סוג תקלה</label>
                    <select 
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none bg-white"
                      value={advancedFilters.faultType}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, faultType: e.target.value }))}
                    >
                      <option value="ALL">הכל</option>
                      {state.faultTypes.map((t, i) => <option key={i} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-500 mb-1 uppercase tracking-wider">עמדה / במה</label>
                    <select 
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-primary outline-none bg-white"
                      value={advancedFilters.platformType}
                      onChange={(e) => setAdvancedFilters(prev => ({ ...prev, platformType: e.target.value }))}
                    >
                      <option value="ALL">הכל</option>
                      <option value="BAMA">במה</option>
                      <option value="EMDA">עמדה</option>
                    </select>
                  </div>
                </div>
                <div className="mt-4 flex justify-end gap-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setAdvancedFilters({
                      customerName: '',
                      projectNumber: '',
                      platformType: 'ALL',
                      faultType: 'ALL',
                      status: 'ALL',
                      date: ''
                    })}
                  >
                    נקה הכל
                  </Button>
                </div>
              </div>
            )}
            
            {!showAdvancedSearch && showSuggestions && suggestions.length > 0 && (
              <div className="absolute z-50 w-full mt-2 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
                {suggestions.map((s, idx) => (
                  <button
                    key={idx}
                    className="w-full text-right px-4 py-3 hover:bg-gray-50 border-b border-gray-50 last:border-0 transition-colors flex items-center gap-3"
                    onClick={() => {
                      setSearchQuery(s || '');
                      setShowSuggestions(false);
                    }}
                  >
                    <Search className="w-4 h-4 text-gray-400" />
                    <span className="font-medium text-gray-700">{s}</span>
                  </button>
                ))}
              </div>
            )}
            {showSuggestions && searchQuery.trim() && (
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setShowSuggestions(false)}
              ></div>
            )}
          </div>

          <div style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}>
            {viewMode === 'WEEKLY' ? (
              <WeeklyView currentDate={currentDate} jobs={state.tasks} />
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                {/* Operations */}
                <div className="space-y-3 md:space-y-4">
                  <div className="sticky top-[108px] md:static bg-gray-50 z-20 py-2 border-b-2 border-primary flex items-center justify-between">
                    <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <span className="p-1.5 bg-red-100 rounded text-primary"><TableIcon size={18} /></span>
                      תפעול ושירות
                      <span className="text-sm bg-primary text-white px-2 rounded-full">{operationsJobs.length}</span>
                    </h2>
                  </div>
                  {operationsJobs.map(job => (
                    <JobCard key={job.id} job={job} statuses={state.jobStatuses} onEdit={handleEditJob} onDelete={handleDeleteJob} />
                  ))}
                  {operationsJobs.length === 0 && <div className="text-center py-8 text-gray-400 border-2 border-dashed rounded-xl">אין משימות</div>}
                </div>

                {/* Projects */}
                <div className="space-y-3 md:space-y-4">
                  <div className="sticky top-[108px] md:static bg-gray-50 z-20 py-2 border-b-2 border-amber-500 flex items-center justify-between">
                    <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <span className="p-1.5 bg-amber-100 rounded text-amber-700"><Layout size={18} /></span>
                      פרויקטים
                      <span className="text-sm bg-amber-500 text-white px-2 rounded-full">{projectJobs.length}</span>
                    </h2>
                  </div>
                  {projectJobs.map(job => (
                    <JobCard key={job.id} job={job} statuses={state.jobStatuses} onEdit={handleEditJob} onDelete={handleDeleteJob} />
                  ))}
                  {projectJobs.length === 0 && <div className="text-center py-8 text-gray-400 border-2 border-dashed rounded-xl">אין פרויקטים</div>}
                </div>
              </div>
            )}
          </div>
        </main>

        <button
          onClick={() => { setEditingJob(undefined); setIsModalOpen(true); }}
          className="md:hidden fixed bottom-6 left-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg flex items-center justify-center z-40"
        >
          <Plus size={32} />
        </button>

        {isModalOpen && (
          <JobForm 
            initialData={editingJob} 
            selectedDate={currentDate}
            onSave={handleSaveJob} 
            onCancel={() => { setIsModalOpen(false); setEditingJob(undefined); }}
            availableLeads={state.teamLeads}
            availableWorkers={state.assistantTeams}
            statuses={state.jobStatuses}
            faultTypes={state.faultTypes}
            onUpdateFaultTypes={handleUpdateFaultTypes}
            customerMemory={state.customerMemory}
          />
        )}

        {isAdminOpen && (
          <AdminPanel 
            users={state.users}
            leads={state.teamLeads}
            assistants={state.assistantTeams}
            statuses={state.jobStatuses || INITIAL_STATUSES}
            fullState={state} // Pass full state for backup
            onUpdateUsers={(users) => setState(prev => ({ ...prev, users }))}
            onUpdateLeads={(leads) => setState(prev => ({ ...prev, teamLeads: leads }))}
            onUpdateAssistants={(assistants) => setState(prev => ({ ...prev, assistantTeams: assistants }))}
            onUpdateStatuses={handleUpdateStatuses}
            onRestore={handleRestoreState} // Restore function
            // Delete Handlers
            onDeleteUser={(id) => setState(prev => ({ ...prev, users: prev.users.filter(u => u.id !== id) }))}
            onDeleteLead={(id) => setState(prev => ({ ...prev, teamLeads: prev.teamLeads.filter(l => l.id !== id) }))}
            onDeleteAssistant={(id) => setState(prev => ({ ...prev, assistantTeams: prev.assistantTeams.filter(a => a.id !== id) }))}
            onUpdateFirebaseConfig={(config) => setState(prev => ({ ...prev, firebaseConfig: config }))}
            onToggleCloud={(enabled) => setState(prev => ({ ...prev, isCloudEnabled: enabled }))}
            onClose={() => setIsAdminOpen(false)}
          />
        )}

        {isScheduleSenderOpen && (
          <ScheduleSenderModal 
            jobs={state.tasks}
            availableLeads={state.teamLeads}
            onClose={() => setIsScheduleSenderOpen(false)}
          />
        )}
      </div>

      <div className="hidden print:block print:w-full print:absolute print:top-0 print:left-0 print:bg-white print:z-50 print-only">
        <PrintTable date={currentDate} jobs={displayJobs} />
      </div>
    </>
  );
}